package com.accenture.lab.carfast.test;


public class Test1K {
	private static int i0;
	private static int i1;
	private static int i2;
	private static int i3;
	private static int i4;
	private static int i5;
	private static int i6;
	private static int i7;
	private static int i8;
	private static int i9;
	private static int i10;
	private static int i11;
	private static int i12;
	private static int i13;
	private static int i14;
	private static int i15;
	private static int i16;
	private static int i17;
	private static int i18;
	private static int i19;
	public Test1K(){
	}


	//Method
	public static void meth_1( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		if(((i10+i6)<(-4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i10 = ((i5+i9)/7);
		}

		for(int i = 0; i < 5; i++){
			i17 = ((i4-i8)+i17);

		}

		switch(i11){
		case 0:
			i17 = ((i19%(-8))-(i13-i9));
			break;
		case 1:
			i11 = ((i12%(-8))%(-3));
			break;
		case 2:
			i13 = (i0/(-5));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i19 = 4;
		}

		if(((-3)<(i1%(-4)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i13 = (i15%(-5));
		}

		for(int i = 0; i < 1; i++){
			if( (i15==i11)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( (i4==(i15%(-7)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i15 = 6;
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 4; i++){
			if( (6==i15)){
				System.out.println("Hello");
				if( (9==i16)){
					i5 = (i18/(-7));
					if( (i6>=(i14*i15))){
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						if( (2!=(i12+i10))){
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							if( ((-5)>i19)){
								i3 = ((-7)-i9);
								if( ((i19-i12)>=(-5))){
									System.out.println("Hello");
									if( ((i15*i16)>(i0%5))){
										i1 = ((i15/(-3))+(-1));
										if( ((i8*i1)!=(i12*(-1)))){
											i4 = ((-6)+i18);

										}
									}
								}
							}
						}
					}
				}
			}
		}

		if((i4>8)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i7 = ((i8%2)-i5);
		}

		for(int i = 0; i < 9; i++){
			i1 = (i13*(-7));

		}

		if((((-8)<(i11/4))&&(i18>i16))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i18>=(-2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i4<(i1%4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( ((i5/(-1))<=i1)){
				i17 = ((-8)%(-9));

			}
		}if( ((i1+i4)>=(i6/(-4)))){
			System.out.println("Hello");

		}if( ((i2+i4)!=(i14*i7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( (((i3+i17)!=i15)&&((i18*i6)==(i8%(-3))))){
				System.out.println("Hello");
				System.out.println("Hello");
				if( (i15>=(-2))){
					System.out.println("Hello");
					if( (i18<i10)){
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						if( (i0<=i18)){
							System.out.println("Hello");
							System.out.println("Hello");

						}
					}
				}
			}
		}
		switch(i19){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i8 = (i16*3);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 8; i++){
			if( ((i9+i5)<(-7))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( (i17>=2)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( (i15>i19)){
				i4 = (i10*(-3));
				if( (i17<7)){
					i10 = ((i11%6)+i2);

				}
			}
		}if( (i18>(-6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( ((-8)>i9)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if(((i15%(-5))>=i9)){
			i15 = (4-i17);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i5){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i5+i19)!=8)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i18){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i6 = ((i16-i15)/(-5));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i0 = ((i2+i7)-(i3+i2));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 7; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i11){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i16 = ((i2-i4)/(-9));
			break;
		default :
			i18 = (i9%(-6));
		}

		for(int i = 0; i < 6; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 9; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( ((i16%(-5))!=(i2+i7))){
			i15 = ((i13*i2)*i0);

		}if( (i0<(-6))){
			System.out.println("Hello");
			if( ((i6+i0)==(i9%(-9)))){
				i0 = ((i8%1)+4);
				if( (4<(i3*i11))){
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");

				}
			}
		}if( (i6>i8)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 7; i++){
			if( (4!=(i19%8))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if((((-6)<(i13*i17))||(i2>=6))){
			i0 = i17;
		}
		else{
			i8 = (3-i12);
		}
		if( (((i18+i10)>=(-7))&&((i19-i8)<(-5)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( ((i12-i7)==(i4/(-9)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				if( ((i16/(-5))>(i18*i11))){
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					if( (9==i10)){
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");

					}
				}
			}
		}
		for(int i = 0; i < 8; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i18){
		case 0:
			i11 = (i5/(-6));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i2 = ((i5-i12)+(-7));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i8!=(i17/9))){
			i12 = i11;

		}
		for(int i = 0; i < 5; i++){
			System.out.println("Hello");

		}

		for(int i = 0; i < 8; i++){
			if( ((i2%(-8))<=9)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( (i16<i6)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 6; i++){
			if( ((-1)>=i8)){
				i10 = (6*i17);

			}
		}

		for(int i = 0; i < 4; i++){
			if( ((i19*(-7))<i2)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((i7>=5)||(i8>i7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i2-i13)>(i16/9))){
			i15 = (i10/(-8));

		}
		if(((i1-i5)!=(-6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i1){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			i7 = ((-6)*(-7));

		}

		switch(i4){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
	}


	//Method
	public static void meth_2( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i3 = (i11+(i14-i19));
		}

		switch(i12){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i11 = (-7);
			break;
		case 3:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((((i1<(-2))&&((i3/5)<(-7)))&&(i14<=4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i3 = (i3+i7);
		}

		if(((i11==9)&&(i3<(i1/(-7))))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
		}
		if( (i6>=3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i18){
		case 0:
			i12 = ((-9)*(i14-i7));
			break;
		case 1:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 2:
			i11 = (2+i10);
			break;
		case 3:
			i6 = (1*2);
			break;
		case 4:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i14){
		case 0:
			i6 = ((i2%8)*i16);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i14 = (1*(-4));
		}

		switch(i14){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 3:
			i11 = (i14+i4);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			i3 = i6+2;

		}

		switch(i10){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i14<=(i2-i13))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}

		switch(i16){
		case 0:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		default :
			i17 = ((-2)+i19);
		}

		if(((i12-i10)!=(-7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i1 = (i15-i17);
		}

		switch(i12){
		case 0:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		default :
			i15 = (i19/6);
		}

		if(((-7)!=i19)){
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i16){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i16 = ((-5)*(i9-i3));
			break;
		default :
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}

		for(int i = 0; i < 1; i++){
			if( (i6>9)){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 8; i++){
			if( (i12>=4)){
				i9 = ((i15%(-7))*(-1));

			}
		}

		if((i4>(-2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i3 = (-2);
		}
		if( ((i19*i9)<=i14)){
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

		}
		switch(i12){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i18 = ((-8)/(-8));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i11!=i1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i19){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i11 = ((i6+i16)-(i13%1));
		}

		for(int i = 0; i < 7; i++){
			i10 = ((-7)/6);

		}

		switch(i18){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i2 = ((-1)*i4);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i13){
		case 0:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i1 = ((i1*i3)-i1);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}

		if((7<i0)){
			i9 = 7;
		}
		else{
			i3 = ((i4%4)*3);
		}

		if(((((i14/(-7))>(-1))&&((i17*i13)>(-9)))&&((i8/(-9))<(-1)))){
			i7 = (3/(-7));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i14%3)<(i7+i3))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			if( (8<=i16)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i13){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i17 = (i11%(-4));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i4 = ((i10-i12)/(-8));
		}

		switch(i18){
		case 0:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i19>=5)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i13){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i18 = i10;
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i10 = i19;
		}

		if((i0!=(-9))){
			i19 = ((i2*i0)+7);
		}
		else{
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}
		if( ((-3)>i16)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 7; i++){
			if( (i6>(i14-i13))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i4){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i10 = ((i18*i12)-(-4));
			break;
		case 2:
			i12 = ((-2)/(-8));
			break;
		default :
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}

		switch(i0){
		case 0:
			i17 = i4;
			break;
		case 1:
			i11 = (5+(-4));
			break;
		case 2:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i6 = ((i10%5)*7);
			break;
		default :
			i0 = i1;
		}

		for(int i = 0; i < 6; i++){
			if( (i12<=(-2))){
				System.out.println("Hello");

			}
		}

		if((((i0>5)||(5>(i11+i6)))||(i8>=(i18*i11)))){
			i7 = (i0*7);
		}
		else{
			i19 = ((-3)-(i9*i4));
		}

		for(int i = 0; i < 8; i++){
			if( (i8<(i13%(-4)))){
				i9 = (5-(i11-i17));

			}
		}
	}
	public static void entryMeth(int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
		meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
	}

	public static void main(String[] args) {
		entryMeth(Integer.parseInt(args[0]),
				Integer.parseInt(args[1]),
				Integer.parseInt(args[2]),
				Integer.parseInt(args[3]),
				Integer.parseInt(args[4]),
				Integer.parseInt(args[5]),
				Integer.parseInt(args[6]),
				Integer.parseInt(args[7]),
				Integer.parseInt(args[8]),
				Integer.parseInt(args[9]),
				Integer.parseInt(args[10]),
				Integer.parseInt(args[11]),
				Integer.parseInt(args[12]),
				Integer.parseInt(args[13]),
				Integer.parseInt(args[14]),
				Integer.parseInt(args[15]),
				Integer.parseInt(args[16]),
				Integer.parseInt(args[17]),
				Integer.parseInt(args[18]),
				Integer.parseInt(args[19]));
	}

}