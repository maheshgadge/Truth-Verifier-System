package com.accenture.lab.carfast.test;


public class Test {
private static int i0;
private static int i1;
private static int i2;
private static int i3;
private static int i4;
private static int i5;
private static int i6;
private static int i7;
private static int i8;
private static int i9;
public Test(){
}


//Method
 public static void meth_1( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9){
if( ((i7+i4)>=(i8%(-5)))){
System.out.println("Hello");
System.out.println("Hello");
if( ((i3%i7)!=(-8))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
switch(i9){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i6){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i3 = ((i2*i3)%(-8));
 break;
default :
i6 = i1;
}

switch(i7){
case 0:
i8 = (i2*i4);
 break;
case 1:
i1 = ((i0-i2)%i5);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i5>=(-8))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 7; i++){
 if( ((i8==(i8/i4))&&(i5>(-2)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( ((i0/i1)>i0)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}

switch(i6){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i7 = ((i8+i7)-(-7));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i3-i8)==1)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i4 = (4-i1);
}

switch(i3){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i7 = ((i1%i5)*i8);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 6; i++){
 i8 = (-5);

}
if( ((-6)>(i7/i5))){
i1 = ((i4/i1)+i6);

}
for(int i = 0; i < 1; i++){
 if( (i2>=(-7))){
i3 = 7;
if( (i2>=(i1%i7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}
}


//Method
 public static void meth_2( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9){

if((((i3==3)||((((i5*i6)<i0)&&((i3/i5)>=(i7/i3)))&&(i4<=i1)))&&(1<(i9%i2)))){
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((-5)==i3)){
i6 = ((-4)%(-3));
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 3; i++){
 i9 = ((i5+i7)*(i5+i8));

}

if((i8!=(i8-i1))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i0 = (8+(i9+i5));
}

switch(i5){
case 0:
i7 = ((i1-i6)-(i7%i3));
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i8 = (i4*i5);
}

switch(i0){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i8 = ((i0/i1)/i6);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
i9 = (-2);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i6!=8)){
i5 = (7-i7);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i9){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i0/i3)!=2)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
}

switch(i3){
case 0:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i2 = (i1%(i4+i2));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i0){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 3; i++){
 i2 = (i5/i6);

}

if(((i5<(i4/i5))&&((i3%i1)<(i5*i1)))){
i5 = ((-6)*(i1+i7));
}
else{
 meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
}
if( ((i7*i5)<=(i7%i2))){
i6 = (7+(i4%i9));
if( (i7==(-1))){
i2 = ((i5-i7)+i9);

}
}
if(((i7*9)>=(-4))){
i3 = ((-5)/(i6%i5));
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
}


//Method
 public static void meth_3( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9){
if( ((i2+i1)!=(i6%i9))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( (i5!=i2)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( (8==(i3-i4))){
i6 = (i0+(i2-i7));

}if( (i4<=i6)){
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);

}
if((i1==(i1*i3))){
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
}
else{
 i3 = 7;
}

for(int i = 0; i < 2; i++){
 if( ((i5/i3)<=(i0/i2))){
i6 = (i0-(-1));

}
}

if(((i5/i2)!=(i7+i3))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
}

for(int i = 0; i < 8; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

switch(i4){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i3 = ((i2*i6)+i3);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
}
if( (i2==(-7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i4-i9)<=6)){
i7 = (6+(i5%i0));

}
switch(i1){
case 0:
meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i6 = (9+(i1-i7));
 break;
case 3:
i6 = (8*(-2));
 break;
default :
i7 = (i4/i3);
}

switch(i0){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i1 = i6;
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i8){
case 0:
i1 = 4;
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i4 = ((-6)%i0);
 break;
default :
i4 = ((i5%i3)+(i7%i8));
}

if((i3==1)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i8 = ((i3/i6)%(i6%i8));
}

for(int i = 0; i < 8; i++){
 if( ((-7)<=(i7-i1))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
if( ((-2)<=i5)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 1; i++){
 if( ((i9*i2)>(i9*i8))){
i9 = (i3%(-1));

}
}
if( (i4>=(-1))){
meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);

}
switch(i4){
case 0:
i2 = (i3*(-8));
 break;
case 1:
i3 = (i1%(i6+i0));
 break;
case 2:
System.out.println("Hello");
 break;
case 3:
i1 = (i4+(i8%i6));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i8){
case 0:
meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
case 1:
i2 = ((i4+i5)/(i9-i2));
 break;
case 2:
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
 break;
case 3:
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
}
public static void entryMeth(int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9){
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
meth_3(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
}

}