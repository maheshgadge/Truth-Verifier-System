package com.accenture.lab.carfast.test;


public class PureTest {
	private static int i0;
	private static int i1;
	private static int i2;
	private static int i3;
	private static int i4;
	private static int i5;
	private static int i6;
	private static int i7;
	private static int i8;
	private static int i9;
	public PureTest(){
	}


	//Method
	public static void meth_1( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9){

		for(int i = 0; i < 8; i++){
			i5 = (i0*i4);

		}
		if( (4!=i4)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 7; i++){
			if( ((i7%2)<i9)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				if( (((i5%(-8))==(i4-i5))||(i5>i7))){
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");

				}
			}
		}
		if( (5==(i7%(-3)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( ((i4/(-6))!=i6)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				if( ((i3*i9)<(i2-i3))){
					i6 = ((i7/4)*6);
					if( ((i5!=(i7/3))||(i5>i2))){
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						if( ((i5-i6)<(i1/7))){
							i7 = (i5-1);
							if( ((i5+i9)!=(i3-i2))){
								System.out.println("Hello");
								System.out.println("Hello");
								System.out.println("Hello");
								System.out.println("Hello");
								System.out.println("Hello");
								if( ((-6)<=(i8+i6))){
									System.out.println("Hello");
									System.out.println("Hello");
									System.out.println("Hello");
									System.out.println("Hello");
									System.out.println("Hello");
									System.out.println("Hello");
									System.out.println("Hello");
									if( ((i9%(-7))<i9)){
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										if( ((((i0<(i8%(-6)))&&(i8<i3))&&((i2!=(i1%(-7)))&&((i7-i5)<i0)))&&(i6>=(i6-i0)))){
											System.out.println("Hello");
											System.out.println("Hello");
											System.out.println("Hello");
											System.out.println("Hello");
											System.out.println("Hello");
											System.out.println("Hello");
											System.out.println("Hello");
											if( (i7<7)){
												i7 = ((i7%1)/(-1));
												if( (i3>=i9)){
													System.out.println("Hello");
													if( (i4<=(i5*i7))){
														System.out.println("Hello");
														System.out.println("Hello");
														System.out.println("Hello");
														if( (((i5-i4)<=1)&&(5>(i3/9)))){
															System.out.println("Hello");
															System.out.println("Hello");
															System.out.println("Hello");
															System.out.println("Hello");
															System.out.println("Hello");
															System.out.println("Hello");

														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		switch(i2){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			break;
		case 4:
			i2 = (i3+i6);
			break;
		default :
			i0 = ((i5*i9)-(i8+i3));
		}

		for(int i = 0; i < 5; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( (i3>=(-1))){
			System.out.println("Hello");

		}if( (((-5)!=i6)||((-2)<i9))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( (i4!=(i4%6))){
				i0 = ((i9+i0)*(-9));
				if( (((i8+i2)<=(-6))&&((-2)>i6))){
					i8 = (i8/(-8));
					if( ((i3*i6)>(-8))){
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						if( ((i2==(-5))&&(9<=i2))){
							i4 = (9%(-6));

						}
					}
				}
			}
		}}


	//Method
	public static void meth_2( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9){

		switch(i4){
		case 0:
			i4 = (i5+(i7/(-1)));
			break;
		case 1:
			i5 = (1*(i7+i2));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
		}

		if((i1!=(-9))){
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (((i6+i4)<=i5)&&(i0>=(-2)))){
			i0 = ((i0%(-7))/8);

		}
		switch(i8){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i7 = ((-8)+(i7-i8));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i7 = (9%7);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 6; i++){
			i6 = ((i4-i5)-i8);

		}

		switch(i9){
		case 0:
			i4 = ((-2)+i9);
			break;
		case 1:
			i9 = (i0%1);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i6 = (6%(-7));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i4){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i5 = ((i9/(-7))*2);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i1>(-8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 7; i++){
			if( (i1<(-8))){
				i6 = ((-8)%9);

			}
		}

		switch(i2){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i5 = ((i1-i6)*5);
		}

		switch(i2){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i0 = (i6+i4);
		}
		if( ((i1+i9)<1)){
			i3 = (i7*i0);
			if( (i4!=i7)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				if( (((i4/1)<(i6*i3))&&(((i1-i7)==(-4))&&(i3==(-7))))){
					i8 = ((i7-i4)*(-8));
					if( (i6>(i6%(-9)))){
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						if( (((-1)!=i9)||(((i0-i3)<=i6)||((-2)==(i1*6))))){
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							if( (((i2*i0)==9)||((i9+i8)!=(-1)))){
								i7 = ((i5-i6)%9);
								if( ((i3*i6)<(-5))){
									System.out.println("Hello");
									System.out.println("Hello");
									System.out.println("Hello");
									System.out.println("Hello");
									System.out.println("Hello");
									System.out.println("Hello");
									if( (5>=i5)){
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										System.out.println("Hello");
										if( (i4<=(-3))){
											i5 = ((i1*i2)+i2);
											if( ((i2<=9)&&(i5!=9))){
												i8 = ((i7+i5)-(i4-7));
												if( (((i5+i1)>(i6+i5))||((i3%3)<=4))){
													System.out.println("Hello");
													System.out.println("Hello");
													System.out.println("Hello");
													System.out.println("Hello");
													System.out.println("Hello");

												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}}


	//Method
	public static void meth_3( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9){

		for(int i = 0; i < 2; i++){
			i7 = (i0+i7);

		}

		for(int i = 0; i < 8; i++){
			if( ((i5%(-3))<=(i6%2))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				if( (3!=(i8-i3))){
					i8 = (1*i9);
					if( ((i6-(-7))>i6)){
						meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
						if( (((-3)>i5)||(7==(i9/(-1))))){
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");

						}
					}
				}
			}
		}

		for(int i = 0; i < 4; i++){
			if( ((-4)==(i6*i8))){
				i0 = (i6/(-3));

			}
		}
		if( ((i5/7)>(i7+i8))){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i2){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
			break;
		case 2:
			i2 = (3*(-5));
			break;
		case 3:
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
		}
		if( (i9>i6)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((((i1+i2)>1)&&((i2+i4)>=(i3%8)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i1>i6)){
			i2 = ((i8/(-8))%3);

		}
		if((((i5%3)<=(i0/(-8)))&&((i3-i6)<i8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 6; i++){
			if( ((-9)<=(i6/(-1)))){
				i4 = (i4*i4);

			}
		}

		if(((i0%3)!=(i0+(-9)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 9; i++){
			i5 = ((i5*i4)%7);

		}
		if( (i6<=9)){
			System.out.println("Hello");

		}if( ((i5-i9)==(i0+i2))){
			i5 = (i8*(i0*i1));

		}
		for(int i = 0; i < 4; i++){
			if( ((i6*i0)<=3)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 9; i++){
			i8 = (2*(i1*i2));

		}
		if( ((i1*i9)!=i8)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 7; i++){
			if( ((i4/(-5))<=(i5+i1))){
				i2 = ((i4*i9)*(i4*i0));

			}
		}

		switch(i4){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i2 = ((-4)/9);
			break;
		case 2:
			i3 = ((-3)+i2);
			break;
		case 3:
			i6 = i0;
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i1<(i0%(-6)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((-2)<=i3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 6; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		if((i1<=i3)){
			i9 = (3*(i5-i7));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
	}
	public static void entryMeth(int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9){
		meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
		meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
		meth_3(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9);
	}
	public static void main(String args[]){
		entryMeth(
				Integer.parseInt(args[0]),
				Integer.parseInt(args[1]),
				Integer.parseInt(args[2]),
				Integer.parseInt(args[3]),
				Integer.parseInt(args[4]),
				Integer.parseInt(args[5]),
				Integer.parseInt(args[6]),
				Integer.parseInt(args[7]),
				Integer.parseInt(args[8]),
				Integer.parseInt(args[9]));
	}

}