package com.accenture.lab.carfast.test;


public class Test3K {
private static int i0;
private static int i1;
private static int i2;
private static int i3;
private static int i4;
private static int i5;
private static int i6;
private static int i7;
private static int i8;
private static int i9;
private static int i10;
private static int i11;
private static int i12;
private static int i13;
private static int i14;
private static int i15;
private static int i16;
private static int i17;
private static int i18;
private static int i19;
public Test3K(){
}


//Method
 public static void meth_1( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

for(int i = 0; i < 9; i++){
 if( ((i14/7)!=(i8*i7))){
i8 = ((i14/(-4))*(i13+i8));

}
}

for(int i = 0; i < 7; i++){
 i13 = (i19%(-3));

}

for(int i = 0; i < 8; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

if((((i2*i5)<=8)||((i0%(-2))<=(i0*i17)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 8; i++){
 System.out.println("Hello");
System.out.println("Hello");

}

if(((i17%(-6))==i17)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i6 = ((-6)*i13);
}

for(int i = 0; i < 6; i++){
 if( ((-5)!=i11)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (((-9)>=(i17/(-7)))||(i11>8))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}

for(int i = 0; i < 9; i++){
 i7 = (i7/(-4));

}

switch(i15){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i14 = (i14%(-5));
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
i12 = ((-5)/(-7));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i6){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( ((i10%8)!=i2)){
i2 = (3/(-3));
if( ((i8/(-7))>i15)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i16!=(-4))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i5<(i3/1))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (6<=(i0-i18))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i7!=(i15+i10))){
i17 = ((i1*i3)-i7);
if( (i3>i4)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i5!=(-6))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( ((i3-i18)>=i4)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i18>=6)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}
}
}
}
}
}
}
}
if((((i6+i1)<=(-4))&&(((6!=(i15-i19))||((i0+i11)>=i1))&&((i6*i7)<=(i9+i14))))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i10 = (2+i10);
}

for(int i = 0; i < 9; i++){
 System.out.println("Hello");

}

for(int i = 0; i < 9; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 1; i++){
 if( ((7>=i13)&&(i5>=i7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
if( ((i17>=(i10/(-8)))||(i3<(i8*i10)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 2; i++){
 if( ((i14-i15)!=i0)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i15<(i4%7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}

if((i16!=(-3))){
i0 = ((i16-i1)/(-2));
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i4){
case 0:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i7<(i4*i0))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
}

switch(i3){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
i7 = (2*(i2%(-8)));
 break;
default :
i17 = ((i16+i13)/5);
}

switch(i1){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i9 = ((-8)%8);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i13!=8)){
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i16==(-1))){
i16 = (i8-(i17%(-4)));
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i15){
case 0:
i0 = ((i11-i0)+i1);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
}

switch(i13){
case 0:
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i5 = i4;
}

if(((i1>=6)&&(i13<=(-7)))){
i12 = ((i9*i8)/(-1));
}
else{
 i15 = (i1%(-1));
}
if( (i17>(i9*i17))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if(((i7+i17)<=(i12*i6))){
i10 = (i17%(-4));
}
else{
 i19 = ((i4+i8)*(i13%9));
}

for(int i = 0; i < 2; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

switch(i12){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
 break;
case 2:
i8 = (-2);
 break;
default :
i19 = ((i19+i10)*(i8-i9));
}

for(int i = 0; i < 2; i++){
 if( (9<(i12*i5))){
i9 = ((-6)/9);

}
}
if( ((i3+i16)>=i15)){
i13 = ((-7)%6);
if( ((i5*i14)<=5)){
i8 = (i1%2);
if( ((i10+i12)>(-7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i5<=(-1))){
i6 = ((i3*i2)/4);

}
}
}
}if( ((i16%7)<=i6)){
i11 = ((i6/9)-i9);
if( ((-8)>i13)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
if((i2==6)){
i10 = (-5);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i9-i19)>3)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i4+i19)<(i5-i13))){
i12 = ((-1)/8);
}
else{
 System.out.println("Hello");
}
if( ((i18-i2)>i7)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if((((i13/6)<=(-5))&&((i6<=(-2))&&(i17>7)))){
i16 = (i7*i13);
}
else{
 i16 = (7%(-3));
}
if( ((i0>9)||((i13/(-3))<8))){
i0 = (1/(-4));
if( ((i17-i16)<7)){
i3 = ((i19*i13)%2);

}
}if( ((-3)<=(i12+i1))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( (i9==(-8))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if((i7<=4)){
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i4-i6)>=(i11*i0))){
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i13){
case 0:
i13 = ((-2)%(-6));
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
i3 = ((-5)%8);
 break;
default :
i15 = (5/5);
}
}


//Method
 public static void meth_2( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
if( (i0>=(i4*i18))){
i18 = (i1+9);

}
if((2<=i1)){
i0 = 2;
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( ((i14%4)>=i7)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i18>=i17)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (2<(i18-2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( ((-7)>i14)){
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

}
}
}
}
if((i18<(i19*i17))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i13){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i0 = ((-7)/4);
 break;
case 4:
i7 = (i12-i17);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
}
if( ((i13<=(i4*i3))||(i10==(i8-i18)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i18!=(i5-i3))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
for(int i = 0; i < 3; i++){
 if( (((i15/(-4))<i0)||((i5==(i6+i4))&&(4<=i13)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

switch(i19){
case 0:
i6 = ((i5-i18)%2);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i0>4)){
i10 = (6-(i16-i17));

}
switch(i5){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i1 = (i9*i15);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 6; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 6; i++){
 if( (i19>=7)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 5; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

switch(i4){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i15 = ((i19/(-5))+(i16%4));
}

switch(i3){
case 0:
i13 = (i2-i8);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 5; i++){
 i0 = ((-4)%4);

}

switch(i5){
case 0:
i0 = (i19*(i8*i7));
 break;
case 1:
i7 = ((-2)%9);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i14 = i2;
}

for(int i = 0; i < 6; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

switch(i8){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i19 = ((-3)+i6);
 break;
case 3:
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 6; i++){
 i2 = ((i17+i2)/3);

}

switch(i10){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i14 = (8+(i11%1));
 break;
default :
i1 = ((i9+i15)/(-2));
}
if( (i17<=7)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 9; i++){
 if( (i19==(-4))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

switch(i4){
case 0:
i12 = (4*(-8));
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i7 = (i15+i8);
 break;
default :
i14 = (i8/3);
}
if( (i11>=(i17%7))){
i8 = (-2);

}
switch(i18){
case 0:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i4 = i1;
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((((i17<=(-1))||((i14-i2)==i10))&&(2>=(i9/(-8))))){
i18 = ((i19%5)+(-8));
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((2!=(i15/(-4)))||(i2>(i8*i9)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i17 = (i15-3);
}

for(int i = 0; i < 3; i++){
 i14 = ((i10*i18)*(i19/(-2)));

}

switch(i18){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i17){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i18 = (i3*(-1));
}

for(int i = 0; i < 4; i++){
 if( ((i16>i10)||(i7>4))){
i13 = ((i18-i6)*(i3-i9));

}
}

switch(i17){
case 0:
i18 = (i3%9);
 break;
case 1:
i16 = ((i11/3)-(i12+i19));
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i2 = ((-3)/8);
}

for(int i = 0; i < 4; i++){
 if( (i5<=9)){
System.out.println("Hello");

}
}
if( (i2>(-9))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if(((i9-7)>(-3))){
i16 = (6+i7);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((((-8)==i17)&&(i19<=(-5)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (3>(i19*i13))){
System.out.println("Hello");
System.out.println("Hello");

}
switch(i7){
case 0:
i4 = (i12%2);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i16 = ((i6/5)-i1);
}

if(((-7)<=i10)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 8; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if( (i14>=(-3))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i14){
case 0:
i4 = (-8);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i12 = (5+i12);
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i8 = (-1);
}

if(((-6)>(i0-i6))){
i13 = ((i9%(-4))/7);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i19){
case 0:
i13 = (5%6);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i4 = (i5/(-6));
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
}


//Method
 public static void meth_3( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

switch(i15){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i15 = (i17-i1);
}
if( ((i15*i8)<=(-7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i7){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i8 = 9;
 break;
case 2:
i8 = ((-7)*i6);
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
i7 = ((i19%(-9))*(i18+i15));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i12==(-2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i12+i3)<(i10*i16))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 6; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

switch(i7){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i8 = (i3-i9);
 break;
case 2:
i12 = ((i13-i10)/(-2));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i14){
case 0:
i3 = (7%6);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i8){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 7; i++){
 i19 = (3*6);

}
if( ((i10/1)<i11)){
i12 = ((i13-i11)/7);

}if( (8!=i5)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i15){
case 0:
i9 = ((i17+i14)%(-9));
 break;
case 1:
i13 = i1;
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i2!=8)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i15 = (i6*i7);
}
if( (i14!=i1)){
i13 = 9;

}
for(int i = 0; i < 4; i++){
 if( ((i7*i11)==i1)){
i2 = (i9*i15);

}
}

if(((-9)!=(i13+i18))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i10 = (i18-(i18/(-5)));
}

if(((i2%(-2))>6)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i5 = (6*i14);
}

if(((i15-i14)==i9)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (5>i16)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if(((-5)<=(i6-i11))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
}

for(int i = 0; i < 8; i++){
 i6 = 2;

}

for(int i = 0; i < 1; i++){
 if( (i10<=i9)){
System.out.println("Hello");

}
}

switch(i11){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i1 = (-5);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 8; i++){
 System.out.println("Hello");
System.out.println("Hello");

}

switch(i8){
case 0:
i16 = (i15-5);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i9 = ((i13*i14)+i14);
 break;
case 3:
i1 = i15;
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
}
if( ((i15+i8)<(i10+i12))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if((5<(i15/(-8)))){
i3 = ((-7)-(i16-i17));
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 5; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

switch(i6){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i6 = (i14-1);
 break;
case 2:
i16 = (7%(-2));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 3; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 2; i++){
 i17 = ((-7)/8);

}

if(((i12>i3)||(5>=i19))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((((i10*i9)==i1)&&((-9)<=(i12-i9)))||((-4)<i3))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i12 = ((i8-i9)-i10);
}

switch(i1){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
 break;
case 3:
i19 = (i5-i13);
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i9){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i17 = i18;
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 1; i++){
 System.out.println("Hello");
System.out.println("Hello");

}

if((((i0-i5)>i1)||((i16+i0)>=(-9)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i10>(i10-i8))){
i11 = ((i0/3)-1);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
}

if((i4!=(-6))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i15 = ((i2/(-7))*i18);
}

if((i15<=i9)){
i2 = (i19*8);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i0){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 7; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 5; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 7; i++){
 if( (i14>i15)){
i6 = (2/(-2));

}
}

if((i14<(i7/8))){
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
}


//Method
 public static void meth_4( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
if( (i4>=i3)){
meth_3(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

}
switch(i17){
case 0:
i3 = ((-3)%(-8));
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i4 = ((-1)/4);
 break;
default :
System.out.println("Hello");
}
if( (i2>=1)){
System.out.println("Hello");
System.out.println("Hello");

}
switch(i12){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i16>i11)||(((((i6-i14)<=(i1-i6))&&((i12+(-8))>=(i10/(-5))))||(i16==(i0*i7)))||(i16>=(-5))))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i19<i1)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i19 = (i12%7);
}

switch(i7){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i11 = (i8-(-8));
 break;
default :
i17 = (i18*(i19/(-9)));
}

if((1==i15)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i10<i13)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if((((i16-i9)<=(i1*i6))&&((i7+i15)<i17))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 3; i++){
 if( ((i4>5)&&((i0>8)||((-9)>=(i2%(-4)))))){
i14 = (9%3);

}
}
if( (i5<=7)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 6; i++){
 System.out.println("Hello");
System.out.println("Hello");

}

if(((i14-i13)>i4)){
i18 = ((i19%(-4))+(i4*i12));
}
else{
 i16 = ((i13*i0)%2);
}

if((i3>=(i9/(-2)))){
i18 = ((-3)%4);
}
else{
 i18 = 2;
}

switch(i12){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i19 = ((-5)+(i11%(-1)));
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
i17 = i1;
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i4<=i10)){
i13 = (i3+i0);

}
switch(i2){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i12 = ((i16+i5)*(-5));
 break;
case 2:
i11 = (i2%(-8));
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i14 = (2+(i3*i8));
}

switch(i5){
case 0:
i16 = (i11-i18);
 break;
case 1:
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( ((i13+i2)<=i15)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( (i12>1)){
System.out.println("Hello");
System.out.println("Hello");

}
if(((i0%8)!=8)){
i7 = (i10*6);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
}

if(((-9)>i6)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i18){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i2 = (-7);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (((i11/4)!=i6)&&(i2!=(i9*i10)))){
i6 = (i4+i18);

}
switch(i2){
case 0:
i7 = (4-i3);
 break;
case 1:
System.out.println("Hello");
 break;
case 2:
i2 = ((i16+i9)*(i12-i1));
 break;
case 3:
System.out.println("Hello");
 break;
case 4:
i15 = ((i14%9)/(-6));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i7-i15)!=5)){
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (((-6)==i17)||(i19<(-8)))){
System.out.println("Hello");

}
switch(i12){
case 0:
i15 = (3*(i8-i10));
 break;
case 1:
i8 = ((i7%(-2))*i16);
 break;
case 2:
i18 = (-1);
 break;
case 3:
i5 = ((-2)+(-8));
 break;
default :
i19 = ((-7)+(i6+(-7)));
}
if( ((-2)<i5)){
i14 = ((i15*i13)+i15);

}
if((8>=i19)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (((-2)!=i6)||(i4==(-5)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i9){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i19<(-4))){
i12 = ((-6)%(-5));

}
if(((-6)==i4)){
i18 = ((-7)-8);
}
else{
 i12 = (5+i13);
}

if((6>=(i7/(-7)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i18 = ((i19*i16)*(-8));
}

for(int i = 0; i < 8; i++){
 if( ((i18+i12)<(i14-(-4)))){
i2 = (i17*(i7*i2));

}
}
if( (8<(i3/(-5)))){
System.out.println("Hello");
System.out.println("Hello");

}
switch(i2){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 1; i++){
 if( (i12<=i8)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

switch(i15){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i9 = (-8);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i4){
case 0:
i0 = (i15/7);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i14 = (i10*i17);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((2<=(i15/(-9)))){
i2 = (2%2);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 4; i++){
 if( (i11!=2)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 6; i++){
 if( (i10>=7)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

if(((i17-i19)>i15)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
}
if( (i19<=(-9))){
i10 = (2*5);

}
switch(i17){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i16 = ((i10-i14)+(i11+i6));
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i4 = ((i17-i8)-i6);
}

for(int i = 0; i < 8; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 7; i++){
 i12 = ((i4*i16)-5);

}

switch(i17){
case 0:
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i2 = i7;
}

for(int i = 0; i < 5; i++){
 if( (i17!=9)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

if((i11>(-9))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i3>(-6))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 3; i++){
 if( ((9>i10)&&((i15+i13)<=9))){
i12 = (i5%4);

}
}

switch(i17){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i15 = ((i17-i2)%(-3));
 break;
case 3:
i19 = i0;
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i19/6)>=i15)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i5 = (i2%(-4));
}

switch(i0){
case 0:
i1 = ((i18/8)+i4);
 break;
case 1:
i10 = i9;
 break;
default :
i12 = (i7+2);
}

for(int i = 0; i < 5; i++){
 System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 1; i++){
 if( ((((i7%4)<=(i0-i9))||((i16-i7)<i15))&&(i7>i12))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}


//Method
 public static void meth_5( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

if((i8==6)){
i8 = ((-1)+8);
}
else{
 meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
}
if( (i11<=(-2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if(((-2)!=(i2*i15))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i2/2)==i16)){
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i8 = 3;
}

if((i7<=1)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
}
if( ((i5%8)<=(i14+i2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 8; i++){
 if( (i5<(i9%(-6)))){
System.out.println("Hello");

}
}

for(int i = 0; i < 1; i++){
 if( (((i16+i14)>(i12%(-8)))&&((i0%8)<=5))){
i16 = ((i7/(-1))%(-7));

}
}

for(int i = 0; i < 7; i++){
 if( ((-1)>i12)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 3; i++){
 if( ((i14-i18)!=2)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 8; i++){
 if( (i8>(-7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 8; i++){
 if( (1>i4)){
i12 = (i7*(-7));

}
}
if( ((i4%1)<=i16)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 5; i++){
 if( (i4!=6)){
i15 = (i14/(-6));

}
}

for(int i = 0; i < 1; i++){
 i14 = ((-3)*7);

}

for(int i = 0; i < 9; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if( ((i16%5)>(i15/(-3)))){
i5 = (7%6);

}if( ((i1*i16)<9)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i2){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i16){
case 0:
i13 = (i5*(i7/3));
 break;
case 1:
i18 = (i11*(i4/2));
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i2){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i17 = (3%9);
 break;
case 2:
i7 = i6;
 break;
case 3:
i6 = ((i11%(-9))-(i4%(-1)));
 break;
default :
i12 = (i5*(i1%(-3)));
}
if( (i13!=(-1))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 1; i++){
 if( ((i17==(-3))&&(i11!=i10))){
i15 = i7;

}
}

for(int i = 0; i < 1; i++){
 i2 = i0;

}
if( ((i1*i2)!=(i16/5))){
i18 = (i2+i16);

}
switch(i5){
case 0:
i15 = (9*(i18/8));
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( ((-4)<(i14*i12))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 6; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

if((i11==(-3))){
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i7 = (8*i19);
}
if( ((i19<=7)||(i15<=(-4)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( (i0==4)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 6; i++){
 System.out.println("Hello");
System.out.println("Hello");

}

switch(i1){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i2!=(-9))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i16<i5)||(i8<(-9)))){
System.out.println("Hello");
System.out.println("Hello");

}
if(((i19>i3)||(i0==(-1)))){
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i10 = 3;
}

if(((i12%(-2))>i1)){
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i2){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i0 = ((-6)+1);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i1/2)>6)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
}

switch(i8){
case 0:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i0 = (7/9);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i3 = ((i0/(-7))%9);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i19){
case 0:
i8 = ((-9)%(-5));
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i18 = (i6%3);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 7; i++){
 if( ((i0-i10)<(i13%(-2)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 5; i++){
 i6 = ((i7/(-1))-i9);

}

for(int i = 0; i < 3; i++){
 if( (i17<(-2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 3; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if( ((-4)!=i0)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( (i5<i19)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if(((-8)<=i11)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i11 = ((i2/8)+(i0+(-6)));
}

if((i17==i11)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i6){
case 0:
i13 = ((i14*i1)*1);
 break;
case 1:
i17 = ((i12/(-9))+i1);
 break;
case 2:
i13 = (5*i2);
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i18 = (i3-(-3));
}

for(int i = 0; i < 7; i++){
 if( (((i16/1)==i18)||((i14%(-9))<i1))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
if( (i12<=7)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 5; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

if((i4==(-9))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
}
if( (i11<i3)){
i5 = (-8);

}
for(int i = 0; i < 8; i++){
 if( ((((i13*i12)>=i13)||(i0>=i17))&&((-2)<(i12%9)))){
i2 = ((i0*i14)%(-2));

}
}

for(int i = 0; i < 1; i++){
 i5 = (i18-4);

}

switch(i1){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((-1)>(i13*i2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i15){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i17>=(i5/7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i15*i3)==i13)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i16*i9)!=i9)){
System.out.println("Hello");
System.out.println("Hello");

}
switch(i10){
case 0:
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i16 = ((i18/4)*(-1));
}
}


//Method
 public static void meth_6( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

if(((-6)>=(i10+i13))){
i13 = i4;
}
else{
 meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
}

switch(i3){
case 0:
i3 = (i9-(i3%5));
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i11>(i12%7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i9){
case 0:
i12 = ((-2)*(i6+i19));
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i13 = i18;
 break;
case 3:
i12 = (2*(i2+i3));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 6; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

if(((i18*i9)>=i5)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (5<i5)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i12){
case 0:
i11 = (i11%6);
 break;
case 1:
i9 = ((i1*i11)/1);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
}

if(((i1<(-1))||((6==(i1*i5))&&((-2)<=i12)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i19*i6)!=(i12+i7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i11<=i10)){
i19 = (i1-i8);

}
for(int i = 0; i < 7; i++){
 if( ((i5-i9)<3)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

switch(i8){
case 0:
i18 = (1%(-1));
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
}

for(int i = 0; i < 3; i++){
 if( (((8==i3)&&((-2)!=i18))||((-1)!=(i3*i1)))){
i4 = ((i10*i9)%2);

}
}

if(((i3/6)<=1)){
i13 = ((i9/(-1))/3);
}
else{
 i19 = (-5);
}
if( ((i1-i2)>=(i16/2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i15/(-4))<=(-2))){
i13 = (i12%6);

}
for(int i = 0; i < 2; i++){
 if( ((i13+i15)>5)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

switch(i14){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i0 = ((-3)-i12);
 break;
default :
System.out.println("Hello");
}

for(int i = 0; i < 1; i++){
 if( (((i5%(-2))<(i7%(-3)))||((-1)<=(i2%2)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

if((((i5+i13)<=(-1))||(4<=(i12/(-7))))){
i15 = (i10/2);
}
else{
 i7 = ((-5)/2);
}

if((i6>2)){
i6 = (i2/(-7));
}
else{
 i17 = (i15%3);
}

switch(i3){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i6 = (4+(-9));
 break;
case 2:
i4 = ((i12-i15)%(-9));
 break;
default :
i16 = ((i2+i11)-(i14-i4));
}

if(((i8<(-5))||(i17!=8))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
}

if((i10<4)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i0 = (9%(-2));
}
if( (i0>(i17+i1))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i0){
case 0:
i19 = (i7%(-6));
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i5==(-7))||(i19>(i4/6)))){
i10 = (5-(i16+i10));
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i7<i10)||((-9)>=i12))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i14 = i8;
}

switch(i1){
case 0:
i4 = ((-1)*i4);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i6 = (7+i11);
}

if((i16!=2)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i8 = 8;
}

if((i13>(i3-i7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( ((6>=i10)||((-4)<(i6-i15)))){
i9 = (i10%2);

}
switch(i19){
case 0:
i8 = ((-8)%(-6));
 break;
case 1:
System.out.println("Hello");
 break;
case 2:
i13 = 6;
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i3){
case 0:
i1 = (i16%2);
 break;
case 1:
i2 = (i2-6);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((9>i13)){
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i18==1)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i7){
case 0:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i9 = ((-9)-i2);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i19 = i13;
}

switch(i5){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i4){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i0 = (i6-i9);
 break;
default :
System.out.println("Hello");
}

switch(i7){
case 0:
i11 = ((-7)-i14);
 break;
case 1:
i3 = i8;
 break;
case 2:
i14 = ((i3%(-2))/1);
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
i17 = ((i17/5)%9);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 8; i++){
 if( (((i15/4)==(-3))||(9<i18))){
i13 = ((i1/1)/(-4));

}
}

switch(i19){
case 0:
i19 = (i14+i8);
 break;
case 1:
i5 = ((i16-i5)*(-8));
 break;
case 2:
i0 = (i12%5);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 3; i++){
 if( (2!=(i0+i19))){
i8 = (i10+(-2));

}
}

switch(i0){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i2 = ((-9)%6);
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
i17 = i8;
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((((i8-i17)>(i5*i9))&&((i18*i6)==2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i12){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 2; i++){
 i13 = (i7-(-7));

}

for(int i = 0; i < 5; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 3; i++){
 if( ((-4)>(i7+i8))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}
public static void entryMeth(int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
meth_3(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
meth_4(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
meth_5(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
meth_6(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
}

}