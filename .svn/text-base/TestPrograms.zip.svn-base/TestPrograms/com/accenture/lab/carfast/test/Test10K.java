package com.accenture.lab.carfast.test;


public class Test10K {
	private static int i0;
	private static int i1;
	private static int i2;
	private static int i3;
	private static int i4;
	private static int i5;
	private static int i6;
	private static int i7;
	private static int i8;
	private static int i9;
	private static int i10;
	private static int i11;
	private static int i12;
	private static int i13;
	private static int i14;
	private static int i15;
	private static int i16;
	private static int i17;
	private static int i18;
	private static int i19;
	public Test10K(){
	}


	//Method
	public static void meth_1( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
		if( ((i14*i12)<=i11)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((-4)==(i17/(-5)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i11*i7)>i10)){
			i7 = (9-i8);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i10<=i18)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( (i9==i7)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		for(int i = 0; i < 9; i++){
			if( ((i13-i15)>i1)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				if( (((-1)!=i3)&&((-8)>i19))){
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					if( (i6>=(-2))){
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						if( ((-7)<=(i2%1))){
							System.out.println("Hello");
							if( (i0!=6)){
								i14 = (5-(i11+5));
								if( (1<=(i4-i11))){
									System.out.println("Hello");
									System.out.println("Hello");
									System.out.println("Hello");
									System.out.println("Hello");
									System.out.println("Hello");

								}
							}
						}
					}
				}
			}
		}

		for(int i = 0; i < 4; i++){
			System.out.println("Hello");

		}

		switch(i14){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 7; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 2; i++){
			i7 = (i1-i5);

		}

		switch(i1){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i15 = (i16+6);
		}
		if( ((-5)>i1)){
			System.out.println("Hello");

		}
		if((i1<=(i15-i0))){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i9 = ((i12/7)%6);
		}

		if((i0<=i6)){
			i8 = ((-6)*i0);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			i7 = ((i19+i4)+(i12-i13));

		}

		if((i0==(-8))){
			i8 = (1/6);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 9; i++){
			if( ((1!=(i2+i17))||(i18>=(-6)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				if( ((-6)!=i19)){
					i8 = (i3%1);
					if( ((i13%(-5))!=i18)){
						i10 = ((-8)+(i3%(-9)));

					}
				}
			}
		}

		for(int i = 0; i < 4; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i19){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i3 = (2+(i17*i8));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((-8)<=(i1+i17))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( (i3==6)){
				i1 = ((i15*i0)+i7);
				if( ((i19*9)>=2)){
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					if( (i3>=i14)){
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						if( ((i19%(-6))<=i17)){
							i11 = (6-(i5/8));
							if( ((i12*i13)<=i10)){
								System.out.println("Hello");
								System.out.println("Hello");
								System.out.println("Hello");
								System.out.println("Hello");
								System.out.println("Hello");
								System.out.println("Hello");
								System.out.println("Hello");
								System.out.println("Hello");

							}
						}
					}
				}
			}
		}if( (i5>(i17-i7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( ((i5-i12)>=(i9*i13))){
				i4 = (1/(-2));

			}
		}
		for(int i = 0; i < 1; i++){
			if( ((-7)<=i0)){
				System.out.println("Hello");
				if( (i11!=(-9))){
					i13 = (9%3);

				}
			}
		}

		for(int i = 0; i < 9; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		if((i9!=(i14-i6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i3!=i12)){
			i4 = ((-6)*(-7));
		}
		else{
			i1 = ((i14*i8)%2);
		}

		if((i17>=5)){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i3 = ((-7)%1);
		}

		if(((5<=i7)||((i6/8)<=i6))){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i2){
		case 0:
			i2 = ((-3)-(i6/4));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i5){
		case 0:
			i10 = ((-2)%3);
			break;
		case 1:
			i12 = (i3/(-7));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i3*i9)!=i14)){
			i3 = (i17-3);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i11<i9)){
			System.out.println("Hello");

		}
		for(int i = 0; i < 1; i++){
			if( (((i6*(-7))>=8)&&((i6*i8)>=(-8)))){
				i10 = (i5*(-4));

			}
		}
		if( ((i5+i1)<=i4)){
			i13 = (i19/(-7));
			if( (i18>i15)){
				i11 = ((-5)%(-2));
				if( ((i16-i15)!=i14)){
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					if( (i12==(i13%9))){
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						if( (((i1*i17)<=(-5))&&(i5<(i1*i18)))){
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							if( ((-7)>=i1)){
								System.out.println("Hello");
								System.out.println("Hello");
								System.out.println("Hello");
								if( ((-6)==(i3-i8))){
									i11 = (i11+i16);
									if( ((-1)!=i13)){
										System.out.println("Hello");
										System.out.println("Hello");
										if( ((i13-i2)>=8)){
											i0 = i18;

										}
									}
								}
							}
						}
					}
				}
			}
		}
		if((i10<(i1+i9))){
			i9 = ((-3)*(-2));
		}
		else{
			System.out.println("Hello");
		}
		if( (i14!=(-4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 5; i++){
			if( (((i9/3)==(i13*i2))&&(((-7)<=i1)||((i12*i0)>i9)))){
				i6 = ((i18%4)-(-8));

			}
		}
		if( ((i8*i12)<(i9/(-1)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( (i6!=(-1))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				if( (i13<i18)){
					i18 = (i11+3);
					if( ((-1)==(i3*(-3)))){
						System.out.println("Hello");

					}
				}
			}
		}
		for(int i = 0; i < 6; i++){
			if( (i0>i6)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				if( ((3>i0)||(i15>=(i5+i3)))){
					System.out.println("Hello");
					System.out.println("Hello");
					if( (i18<(i17%3))){
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");

					}
				}
			}
		}

		for(int i = 0; i < 3; i++){
			if( (((i15+i16)!=(-1))&&(7>=(i5%(-1))))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i7){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i19 = ((-3)*(i15*i11));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i4>=4)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
		}
		if( ((((i6*i19)==i10)||(i3<=(-8)))&&(i9<=(-7)))){
			i5 = ((i7%(-2))*(-1));
			if( ((i18%(-1))>=(i12-i19))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		for(int i = 0; i < 1; i++){
			if( (i4>=i13)){
				System.out.println("Hello");
				if( (6>=i8)){
					System.out.println("Hello");
					System.out.println("Hello");
					if( ((i0>=(i6+i15))||((i15<=i2)||(i13<(i10/7))))){
						i5 = ((i17-i12)*i4);
						if( (6>i7)){
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");
							System.out.println("Hello");

						}
					}
				}
			}
		}
		if( ((-4)==(i2/(-1)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}}


	//Method
	public static void meth_2( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
		if( ((i16*i11)==i8)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( (i12>=(-1))){
				meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
				if( (2>(i17-i12))){
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					System.out.println("Hello");
					if( (i13>=i19)){
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");

					}
				}
			}
		}
		for(int i = 0; i < 6; i++){
			if( (((i1%5)<=(i8/7))&&(i5<(i16-(-9))))){
				i16 = (i12-(-9));

			}
		}

		for(int i = 0; i < 6; i++){
			if( (i5<2)){
				i13 = ((i10/(-4))+(-6));
				if( ((5!=(i7%(-1)))||(((i19/(-4))!=i19)&&((-5)==i3)))){
					i8 = ((-7)*i1);
					if( ((-6)==(i14-i19))){
						System.out.println("Hello");
						System.out.println("Hello");
						System.out.println("Hello");
						if( ((-6)>=(i11*i2))){
							meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

						}
					}
				}
			}
		}

		switch(i18){
		case 0:
			i12 = (5%(-1));
			break;
		case 1:
			i13 = ((-5)/(-9));
			break;
		case 2:
			i13 = (-5);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 8; i++){
			if( (i19<=(i3+i7))){
				meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

			}
		}
		if( ((i0!=9)&&((1>i1)&&((i0<=(i7%3))&&((i9+(-2))==(i8%5)))))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( (((i19>=9)||((i13<1)&&(((i0-i3)>(i0+i8))&&(i16<=i11))))||((i13*i8)<(i19-(-3))))){
				i18 = (3+(i9+i12));

			}
		}
		switch(i5){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((((i12-i6)!=1)||(i9==i19))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i17==i12)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i18 = (7+(-8));
		}

		if((i6>=i19)){
			i12 = ((-8)%6);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i9){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i12*i17)>(i13/(-1)))){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i10 = (-9);
		}
		if( ((4<(i15%3))||(i15<i18))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			if( ((i19-i0)==(i15*i1))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}if( ((i16<=(-7))||((((i11/8)>i17)||((i17<5)&&((i14-i15)==9)))||((i19==9)&&(2>(i12/7)))))){
			i9 = ((i7*i12)*(i1*i17));

		}
		for(int i = 0; i < 5; i++){
			if( ((i5-i9)==i9)){
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 1; i++){
			if( (i4!=i16)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if((((-9)!=(i8-i13))||(i8<=9))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i5 = (i3*(i7/1));
		}

		for(int i = 0; i < 9; i++){
			i9 = ((i19/5)*i11);

		}

		if((i19<=(i4/(-6)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i6 = (i0+i6);
		}

		if(((i16*7)<=(-4))){
			i6 = (i3+(-7));
		}
		else{
			i11 = (i2+2);
		}

		switch(i14){
		case 0:
			i2 = ((i9*i17)/(-7));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i16 = (5-(i17*i19));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i6 = ((i11+i8)/(-1));
		}

		for(int i = 0; i < 1; i++){
			i6 = (5*6);

		}

		switch(i5){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i14 = ((i9%7)-4);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i7){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i4>i16)||(i5>=(i16*i17)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i15){
		case 0:
			i10 = ((i17-i19)*(i3-i1));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 8; i++){
			System.out.println("Hello");

		}

		for(int i = 0; i < 1; i++){
			if( ((i3+i10)<=(-1))){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if((4!=(i12+5))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i13 = ((i2-i4)-(i3+i16));
		}

		for(int i = 0; i < 8; i++){
			if( (((i2-i7)>i8)||(3<=i8))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((i4-i0)<i3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 6; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		if((((i1%(-9))>i3)||(7>i4))){
			i4 = ((i9+i17)+(i5+i6));
		}
		else{
			i7 = ((i17+(-4))/(-8));
		}

		for(int i = 0; i < 5; i++){
			if( (i7<(i1-i2))){
				System.out.println("Hello");

			}
		}

		if((5>=i7)){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 4; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 1; i++){
			i1 = ((i3/(-7))%8);

		}

		switch(i12){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i8){
		case 0:
			i8 = (i17%7);
			break;
		case 1:
			i19 = ((i14/1)*(i0*i5));
			break;
		default :
			i0 = ((i18*i8)-5);
		}

		for(int i = 0; i < 1; i++){
			if( (i17<i6)){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if(((i2==(i0/(-4)))||((i10/7)>=6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 1; i++){
			System.out.println("Hello");

		}

		if((5<=(i14+i7))){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i4%(-5))>(i13%(-8)))){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i14!=(i13*i18))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((-8)<(i16-i9))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i11){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i11 = ((i16-i4)/9);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i0){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
		}

		for(int i = 0; i < 4; i++){
			if( (3>=i13)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
	}


	//Method
	public static void meth_3( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		if((8==(i13%(-7)))){
			i5 = (i15%(-5));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i1){
		case 0:
			i5 = ((-7)/7);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		default :
			i1 = ((i6-i1)%(-7));
		}
		if( (1==i9)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (3>=i7)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 2; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 2; i++){
			if( ((i5-i16)<=(-8))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((-5)<i13)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 3; i++){
			if( (i11!=6)){
				i6 = (-4);

			}
		}

		if(((i18%7)>=8)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}

		switch(i15){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i11 = (i2-i5);
			break;
		case 2:
			i18 = (i15+(i13%4));
			break;
		case 3:
			i11 = (9/(-7));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i12/5)<=(i7-i8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i12+i0)>(-5))){
			System.out.println("Hello");

		}if( (i4!=(-6))){
			i13 = (i10/6);

		}
		if((((i1+i6)<=i0)&&(i0>(i19-i2)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((((5>(i0*i18))||((i18/(-2))!=i6))||(5!=i16))){
			i6 = (4%(-9));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((-2)!=(i4-i14))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 6; i++){
			i7 = (i3%2);

		}

		if((i14>9)){
			i15 = (i15%(-6));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 1; i++){
			i11 = ((i1%(-6))+6);

		}
		if( (i2>i19)){
			i19 = (7%4);

		}
		if((3>i6)){
			i11 = ((-7)/1);
		}
		else{
			i12 = (i4-i19);
		}

		switch(i19){
		case 0:
			i15 = ((i5-i19)+(i15+i12));
			break;
		case 1:
			i19 = ((i13-i4)-5);
			break;
		case 2:
			i0 = ((i4%8)+i19);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 4; i++){
			if( ((i19/(-3))==i4)){
				i7 = ((i3/3)/7);

			}
		}

		for(int i = 0; i < 5; i++){
			if( (((i10<3)&&(i5<=(-2)))||(((-6)==i13)||((i4*i7)<=i11)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( (((-1)!=(i1+i15))&&((7>(i14-i12))&&((i16/(-8))>=(i17%(-1)))))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i18!=i11)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i10 = ((i18%1)-(i10*i1));
		}

		if(((i16>(i0%2))&&(i17<=(i8+i9)))){
			i8 = ((i11-i3)-i17);
		}
		else{
			i4 = (-4);
		}

		switch(i7){
		case 0:
			i19 = (i8-i5);
			break;
		case 1:
			i6 = (i15+i1);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i12 = (i18/(-9));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i16/1)>(i3-i0))){
			System.out.println("Hello");

		}
		if((i2>=(-3))){
			i16 = ((-9)/7);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 4; i++){
			if( (((i1*i0)>=(-2))||((-5)>(i7%(-6))))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if(((((i5+i17)==(-5))||(i19>(-7)))&&((-5)>i4))){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i0){
		case 0:
			i0 = ((i18/(-1))/6);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i16 = ((i17%(-9))-(i9/8));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i8){
		case 0:
			i18 = ((i11-i9)%(-4));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i0<i16)){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 5; i++){
			if( (i13>4)){
				i16 = 1;

			}
		}
		if( ((((-5)<i18)||(i8<i16))&&((i12/2)<=i2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i19+i12)<7)){
			i15 = ((i9+i4)/(-6));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i18>=i19)){
			i3 = (i9*(i3/2));

		}if( (2==(i10%6))){
			i10 = (i12*i6);

		}if( ((-2)==i12)){
			i12 = 2;

		}if( (5<=(i14-(-6)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 2; i++){
			i1 = (i14*(-1));

		}

		switch(i14){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (8==i19)){
			i7 = ((i3+i17)-(-5));

		}
		for(int i = 0; i < 9; i++){
			if( ((i9*i17)==(-1))){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i11 = 2;
			break;
		case 2:
			i0 = (i18%(-6));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i14){
		case 0:
			i15 = (1%3);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i19-i6)<=i16)){
			i1 = (i19/(-1));

		}if( ((i19-i10)<(-6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i6>=(i7*i8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i10){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i8 = (4%5);
		}

		if(((i11-i4)==(i19*i11))){
			i0 = ((-6)+i6);
		}
		else{
			i2 = 7;
		}

		switch(i14){
		case 0:
			i17 = ((i0-i8)*(i10/9));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i15){
		case 0:
			i7 = (i2/1);
			break;
		case 1:
			i0 = ((i3-i2)*i2);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i0/(-2))==(-5))){
			i0 = (i4+i9);

		}
		if((i19!=(i4*i3))){
			i19 = ((i14%(-4))/(-6));
		}
		else{
			i19 = (i2%6);
		}
		if( ((((i0%8)<(i15%1))||(i1>(-6)))||((-4)<=i12))){
			i17 = (i12-i6);

		}
		if((((i12==(-9))||(i18>(i3+i8)))||(i3!=i6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i11%(-2))<(-1))){
			i15 = i3;
		}
		else{
			i12 = (i11%(-4));
		}

		for(int i = 0; i < 9; i++){
			if( (((-7)>=i13)||(4<(i2%9)))){
				i19 = ((i11%(-2))/7);

			}
		}

		for(int i = 0; i < 3; i++){
			if( (6>(i19%1))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i13 = (i3-i17);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
		}

		for(int i = 0; i < 4; i++){
			if( (9<(i6%5))){
				i16 = (i19/2);

			}
		}

		for(int i = 0; i < 9; i++){
			if( ((i18<(-2))&&(((i4+i6)==5)&&((((i9+i10)>(i7%5))||((i1/1)>(-1)))&&((-1)!=(i14-i19)))))){
				System.out.println("Hello");

			}
		}

		if((i12==4)){
			i12 = i9;
		}
		else{
			System.out.println("Hello");
		}

		switch(i12){
		case 0:
			i1 = ((-8)+(i1-i8));
			break;
		case 1:
			i12 = (i1-i12);
			break;
		case 2:
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i18 = ((-7)/9);
			break;
		default :
			System.out.println("Hello");
		}

		switch(i13){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i4 = ((i3/(-2))-(-6));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i15 = (i18+i14);
		}

		for(int i = 0; i < 5; i++){
			if( (i14<(i18%1))){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i8){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i10 = (i1*(i19+i7));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i15 = ((-9)*i8);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (((i0*i19)>=(-8))&&((i9-i19)!=4))){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i6<(i3+i6))){
			i9 = ((-3)%(-2));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
	}


	//Method
	public static void meth_4( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
		if( ((i17-(-6))==(-4))){
			meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

		}
		switch(i0){
		case 0:
			meth_3(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			meth_3(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 2:
			i17 = (6*i18);
			break;
		case 3:
			i0 = ((-5)%7);
			break;
		default :
			i17 = (9-i12);
		}
		if( ((i4/3)<=8)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((-7)<=i7)){
			i7 = (9-(i9+i4));

		}if( (((i10*i0)!=(i15/8))&&(i9>=i8))){
			i4 = (2-(i0%(-9)));

		}
		if((i2!=i9)){
			i10 = ((-5)/1);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i2!=(i18%2))){
			i10 = ((i7*i6)/(-2));

		}if( ((i5*(-6))>(-9))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (((-7)!=(i4/8))&&(i12<i13))){
			i9 = ((i12+i11)-i0);

		}
		for(int i = 0; i < 1; i++){
			if( (((i19<=(i3/6))||(i13!=i8))&&(i2<(i17-i16)))){
				meth_3(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

			}
		}

		switch(i6){
		case 0:
			i4 = (i10-(i2/(-8)));
			break;
		case 1:
			i11 = (4/8);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i13){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((((9<i9)||(i15!=(i1%(-3))))||(1>=i4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i10){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i2 = ((-6)-i7);
		}
		if( ((-1)<(i9*i6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (6>=(i12%(-1)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i18){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i13 = ((-4)%(-6));
		}

		if((i3>6)){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((((-3)<=(i7+i5))||((i10*i2)>=i3))&&(((i1+i4)<=i8)||((i18/(-6))<=(i9%(-8)))))){
			i17 = (i16*i11);

		}
		switch(i18){
		case 0:
			i17 = (-1);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
		}

		switch(i12){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i8 = ((-2)+(-9));
		}
		if( (i4<=(i11*i7))){
			i15 = (i7*(i15%(-9)));

		}if( ((i8+i2)<=i4)){
			i11 = 7;

		}
		for(int i = 0; i < 3; i++){
			if( (((i19==(i5*i8))&&(i15>i2))||(i1<(i18%(-1))))){
				System.out.println("Hello");

			}
		}
		if( (((9==(i19%3))||((i12*i9)>i7))&&(i1!=i12))){
			i13 = ((i10-6)-(i2+i16));

		}
		for(int i = 0; i < 6; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i14){
		case 0:
			i13 = (i1/8);
			break;
		case 1:
			i4 = (3+(i1-i6));
			break;
		case 2:
			System.out.println("Hello");
			break;
		case 3:
			i18 = ((i14-i5)+(i13/4));
			break;
		case 4:
			i8 = 4;
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i4>=(i4-i1))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i8 = ((i10-i19)-i10);
		}
		if( (i13>(i0/(-5)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (6<=i13)){
			i9 = ((-1)-6);

		}
		for(int i = 0; i < 5; i++){
			if( (i2<7)){
				i11 = ((-5)/6);

			}
		}

		if((i1>=(i13-7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i15/(-4))>7)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((-6)>i14)){
			i19 = (i5%(-4));

		}if( (((i4>6)||((i19-i18)==(-7)))||((i2%(-6))>=1))){
			i12 = ((i8-i7)+(-1));

		}if( (((-4)>i11)||((i14%9)>i9))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (((i19*i4)==5)||(i7<(i12%6)))){
			i4 = ((i7+i6)+i4);

		}
		if((i2<=i16)){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i2){
		case 0:
			i13 = ((i13/(-6))*(i8%3));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
		}

		for(int i = 0; i < 9; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		if(((i9>=(i14-i18))||(i13>=(-7)))){
			i18 = (i18/9);
		}
		else{
			i9 = ((-7)%(-1));
		}

		for(int i = 0; i < 7; i++){
			if( ((i6*i14)==i14)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 7; i++){
			if( ((-3)!=(i15/(-4)))){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i15){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			i16 = (1%9);
			break;
		default :
			i7 = ((i14%(-7))+(-7));
		}

		if(((i8!=2)&&((((i5+i9)!=2)||(i18>=i8))&&(5>=(i14-i7))))){
			i4 = (i15+i13);
		}
		else{
			i18 = ((i12/(-6))/8);
		}

		for(int i = 0; i < 4; i++){
			if( ((i18-i6)<(i16/8))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i7-i19)!=(i5-i7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i15 = ((i2-i1)+(i3%3));
		}
		if( ((i9*i13)>=4)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i13<=i3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((-3)!=i2)){
			i3 = ((i15*7)%4);

		}
		switch(i7){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i18 = ((i3%4)%(-9));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i13 = ((-3)-5);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((2!=i11)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i10){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			i16 = ((i18/(-8))/(-7));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
		}
		if( (9>(i15%7))){
			System.out.println("Hello");

		}if( ((-4)>=(i12/1))){
			i0 = ((i16%(-6))-i9);

		}
		if((i8==i3)){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((-5)<=(i16+i1))){
			i15 = (i3/(-7));
		}
		else{
			i18 = (i19*i8);
		}

		for(int i = 0; i < 2; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i6){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i10 = ((-9)-(i9%(-4)));
			break;
		default :
			i18 = (6%3);
		}

		switch(i0){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i4 = (4/(-7));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 5; i++){
			if( ((i6-i9)>=(i14/(-3)))){
				i6 = ((i19/3)*(i9+i12));

			}
		}

		for(int i = 0; i < 7; i++){
			i14 = ((-1)-(i19%2));

		}

		switch(i15){
		case 0:
			i10 = ((i3%3)-(-8));
			break;
		case 1:
			i19 = (i14+(-1));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i10 = ((i3-i14)+i19);
		}

		for(int i = 0; i < 9; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( ((i10+i6)!=(i0%9))){
			i17 = (5%8);

		}
		for(int i = 0; i < 5; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 1; i++){
			if( ((i15/(-9))>i17)){
				i13 = ((-8)/6);

			}
		}
		if( (i1>8)){
			i14 = ((-1)*i10);

		}
		for(int i = 0; i < 8; i++){
			System.out.println("Hello");

		}
	}


	//Method
	public static void meth_5( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
		if( ((-8)>=(i12+i10))){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 6; i++){
			i12 = (i8+i16);

		}

		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i3 = (3/(-7));
			break;
		case 2:
			System.out.println("Hello");
			break;
		case 3:
			i16 = i8;
			break;
		default :
			meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}

		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i16 = ((-7)%(-5));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i10 = ((i9/(-4))%(-9));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i16 = 2;
			break;
		case 4:
			i9 = ((i15+i1)-i7);
			break;
		default :
			i12 = ((-2)*(i8/(-7)));
		}

		if(((i17<=(-1))||(i2==(i17-i2)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i15%6)>2)){
			i12 = (i0+i11);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 9; i++){
			if( ((i17+i14)>(i13*i17))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i18){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i0 = (1/9);
			break;
		case 2:
			i18 = ((i10*i15)+(-9));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i0){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i7 = ((-1)*i13);
		}

		if((i12>=i11)){
			i0 = (i14*i9);
		}
		else{
			System.out.println("Hello");
		}

		for(int i = 0; i < 7; i++){
			i14 = ((i15%(-7))-i3);

		}

		switch(i6){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i7 = ((i0%(-5))/2);
			break;
		case 4:
			i3 = ((-4)/(-6));
			break;
		default :
			i18 = (6%7);
		}

		switch(i18){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i2 = (i7-7);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i0>=i18)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i16+i1)<=(i13+i1))){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i8>(i8+i16))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i15){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i1 = ((i6+i17)-i8);
			break;
		default :
			i6 = (9-(i14%2));
		}

		switch(i13){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i15 = (2/4);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i0/6)!=(i10%(-8)))){
			i12 = ((-9)%(-4));

		}
		switch(i18){
		case 0:
			i19 = ((i5-i13)+(i15-i0));
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i3 = (i19*i1);
		}

		for(int i = 0; i < 6; i++){
			i9 = (i10*(i18%8));

		}

		for(int i = 0; i < 1; i++){
			if( ((((i5*i4)>i18)&&(i0<=(i10*i14)))||(i17>(i2-i16)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 7; i++){
			if( (i8>=(i13*i17))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((i1/(-8))<=(i2%(-6)))){
			System.out.println("Hello");

		}
		switch(i15){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i4){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i16 = 6;
		}

		for(int i = 0; i < 9; i++){
			if( (i16>=4)){
				i14 = ((-8)%(-2));

			}
		}
		if( ((i18+i10)<i17)){
			i6 = (i7+i13);

		}if( (i9==(i4/(-7)))){
			i10 = (7/(-3));

		}
		switch(i17){
		case 0:
			i13 = (i1-i5);
			break;
		case 1:
			i2 = (i11-i1);
			break;
		default :
			i2 = (i2+(-6));
		}
		if( (((i19-i17)==6)||((-4)>(i8*i0)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i18>i1)){
			i17 = (3-i18);
		}
		else{
			i5 = (i2+(i6%3));
		}

		for(int i = 0; i < 2; i++){
			if( ((i11>=3)&&(i10!=i6))){
				i14 = ((-3)*(-1));

			}
		}
		if( (((i9/7)!=i13)&&(i17>=(i11+i9)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i19==8)&&((i8/8)<=i4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((((i12%(-8))<=i3)&&((6!=i15)&&((i2>(-3))&&(5!=(i4+i17)))))){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i19){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i15 = ((i10*i15)%(-6));
		}
		if( (i12!=2)){
			i16 = ((i14-i0)%(-4));

		}
		if(((i3>i17)&&((i6/(-2))!=(i9-i16)))){
			i9 = (-4);
		}
		else{
			i7 = 6;
		}

		if(((i11-i9)==(i16+i12))){
			i10 = i1;
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i1!=7)){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 7; i++){
			if( ((i10/3)!=i13)){
				i8 = ((i3%(-2))*(i9+i10));

			}
		}
		if( (i16>=i17)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i12){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i19 = (2*i3);
		}

		for(int i = 0; i < 2; i++){
			if( ((i0%(-4))!=7)){
				i15 = (i15*i1);

			}
		}
		if( (i1!=(i1%8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i8-i15)!=(-8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i14 = (-3);
		}

		switch(i8){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i3!=(i14*i10))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (9>(i3%5))){
			System.out.println("Hello");

		}
		switch(i5){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i13 = ((i7%(-6))+3);
			break;
		default :
			i2 = ((i16+i7)%(-6));
		}

		for(int i = 0; i < 8; i++){
			i19 = (i2*(i13+i10));

		}
		if( ((i4%7)<(i1-i4))){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i0){
		case 0:
			i8 = ((-3)/(-6));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
	}


	//Method
	public static void meth_6( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		switch(i17){
		case 0:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}

		switch(i9){
		case 0:
			i17 = (i12*2);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 4; i++){
			i9 = (i5%(-1));

		}

		for(int i = 0; i < 3; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i6){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i13 = ((i4/(-2))/(-4));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (((i12-i6)>=5)||((-3)==i9))){
			i10 = ((i8%3)/1);

		}if( (i8<5)){
			i15 = 2;

		}
		switch(i4){
		case 0:
			i18 = (i17%(-9));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i6 = (i15/4);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i10 = ((i0-5)*(i10/(-1)));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i7==(-5))){
			i5 = (i0+(i12-i5));
		}
		else{
			i13 = (i7+i15);
		}

		for(int i = 0; i < 2; i++){
			if( (i6!=i19)){
				i9 = ((i3+i6)%9);

			}
		}

		switch(i14){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i14 = ((i17/(-4))/9);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i14){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i2 = ((i11/9)/3);
		}

		for(int i = 0; i < 5; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		if(((i16+i2)<i16)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i10>=(-1))&&(((i6%6)!=i18)&&(i7<2)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i4){
		case 0:
			i14 = (-8);
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
		}

		if(((i4/(-6))<=(i15-3))){
			i4 = i2;
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i15){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i19 = (i2*i13);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 6; i++){
			i16 = ((i0%7)-i5);

		}

		switch(i6){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i9 = (i7/(-4));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i4){
		case 0:
			i16 = ((i0*i6)*(-3));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i17 = ((i8/4)%5);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (4<=i15)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i14-i12)>=(i9-i11))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i17-i2)>5)){
			i16 = 1;

		}if( (i17<(i3-i8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i8){
		case 0:
			i6 = ((i18+i16)*4);
			break;
		case 1:
			i18 = ((i0/(-5))%(-1));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (1>(i7%1))){
			i4 = (i7*(-3));

		}if( ((i19>=i7)||(1==i5))){
			System.out.println("Hello");

		}
		for(int i = 0; i < 5; i++){
			if( ((i0%(-5))==9)){
				i12 = (i11/(-8));

			}
		}

		if((i4<=(-1))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i18){
		case 0:
			i1 = (i5*4);
			break;
		case 1:
			i12 = ((-5)*i19);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i5 = ((-7)/3);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 1; i++){
			if( (((-7)>i17)&&(((9<(i13%(-5)))||((i1<=(i13*i8))||((i0%6)>=(i16/(-1)))))||(i17<=i11)))){
				i6 = (i8%5);

			}
		}

		if((i7==(i4/(-4)))){
			i11 = i18;
		}
		else{
			i14 = (i8*(i1*i13));
		}

		switch(i14){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			i5 = ((i8-i15)+(i5+i3));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i19 = (i5/(-4));
		}
		if( ((8<=i16)||(9>=(i12*i19)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 2; i++){
			if( ((i19-i6)!=i4)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((-3)>=i18)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i10 = (i15+(-6));
			break;
		case 2:
			i2 = ((-7)-i8);
			break;
		default :
			i11 = (i11*(-4));
		}

		switch(i0){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i5 = (i0/1);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i10){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			i4 = 4;
			break;
		default :
			System.out.println("Hello");
		}
		if( ((i11+i15)!=i15)){
			i14 = i2;

		}
		switch(i13){
		case 0:
			i19 = (i3/(-9));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i16 = (i8*i6);
		}
		if( ((i15<(-5))&&((-1)<=(i10*i17)))){
			i5 = (i4/(-9));

		}if( ((i13/3)!=(i9-i19))){
			System.out.println("Hello");

		}
		switch(i2){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i0 = (i7+(i6%(-8)));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 3; i++){
			if( (((i11-i14)>(i15-i13))&&(i1!=(-1)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if((i11!=(-4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i9 = (i11*i8);
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i0 = (9+(i12+i5));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((-2)>i3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i5+i6)!=i0)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i0 = (6%(-5));
		}

		if((5!=i16)){
			System.out.println("Hello");
		}
		else{
			i16 = ((i0-i12)+(i15-i6));
		}

		if((i4<(-9))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i15==(i18%(-6)))){
			i16 = (i7*i9);

		}
		if(((i14/(-8))<1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i14/7)<=i14)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}}


	//Method
	public static void meth_7( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		for(int i = 0; i < 1; i++){
			i6 = ((-1)/(-5));

		}

		for(int i = 0; i < 9; i++){
			if( (i11>=(i2%(-3)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((i17==i12)||((i8/(-2))<(i12/8)))){
			i1 = ((i4-i7)/5);

		}
		for(int i = 0; i < 9; i++){
			if( ((i11*i9)!=3)){
				meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

			}
		}

		if(((i6*i0)>(i9*i7))){
			i15 = ((i4+i9)/5);
		}
		else{
			i2 = ((i12%4)*i10);
		}

		if((i18<=i15)){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i6){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i7 = (i14%6);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 5; i++){
			if( ((i12/(-2))!=i13)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if(((i10-i16)!=(i4+i7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i2 = (i5+i7);
		}

		if(((i14+i3)<9)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i18 = ((i8-i15)+4);
		}

		if(((i13>(i2%(-4)))&&((i6+i9)<(-5)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i9 = ((i2%(-7))%(-8));
		}

		switch(i4){
		case 0:
			i2 = ((i12/4)*(i16%(-4)));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i17 = (-4);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i14>(-5))){
			i4 = (5/3);
		}
		else{
			i5 = i1;
		}

		if((i12==(i5+i13))){
			i1 = ((i10+i19)%(-7));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 3; i++){
			i16 = (i5*i0);

		}

		if(((i3<=(i18-i12))&&(i10>i16))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i14 = (5*(i16/(-3)));
			break;
		case 3:
			i0 = ((-9)%(-7));
			break;
		case 4:
			i6 = ((i13%8)-i19);
			break;
		default :
			i1 = (i3*(-5));
		}

		switch(i9){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			i14 = (i19+i11);
			break;
		default :
			i9 = ((i18/(-4))+i15);
		}

		if(((-3)<(i4+i10))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 4; i++){
			if( ((i7-i9)>8)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if((5>i9)){
			i4 = ((i19*i3)-(i16+i5));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i8){
		case 0:
			i7 = (i1*(-2));
			break;
		case 1:
			i19 = ((i5+i3)%(-6));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i10 = ((i18+i7)-(-8));
			break;
		case 4:
			i16 = (i13*i18);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			if( (i0<i18)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i17*i4)<i10)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i15-i14)!=i12)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i10*i7)<(i9+i4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 5; i++){
			i5 = ((-9)%4);

		}
		if( (i12!=(-7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i9!=i18)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i2!=(-8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i5!=(-3))||(i18!=(-3)))){
			i14 = ((i4*5)%5);

		}
		if((7<=i19)){
			i19 = i13;
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 9; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 7; i++){
			if( ((-3)!=i14)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 4; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i7){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			break;
		default :
			i19 = ((i5-i17)/1);
		}

		for(int i = 0; i < 9; i++){
			System.out.println("Hello");

		}

		for(int i = 0; i < 7; i++){
			i15 = ((i5/2)-5);

		}

		switch(i9){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i10 = (8+6);
			break;
		case 4:
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i6>=(i18-i13))){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i15){
		case 0:
			i8 = ((i19*i8)*(i19/4));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i10*i0)>=(i18-i1))){
			i1 = (-7);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i11){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i8 = ((i12/3)-(i9+i17));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i17>3)){
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i14==(i12*i7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((-5)<(i18*i14))){
			i0 = i15;
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i3){
		case 0:
			i8 = ((-1)-3);
			break;
		case 1:
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i9/(-2))!=(i9/4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i1 = (i11*i1);
		}

		switch(i10){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			i5 = (8+i5);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i11<5)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i6-5)!=(-8))){
			i4 = 7;
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i0+i4)>=i7)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i11<(i19/7))){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 9; i++){
			if( (i1!=i15)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i13){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i3 = ((i0*i13)-i15);
			break;
		case 2:
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i8-i9)<(-6))){
			i3 = ((-5)/7);
		}
		else{
			i14 = ((i4%(-4))%3);
		}

		if((((i6-i1)<=i10)&&((i10+i19)>=i6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i5){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i4 = ((i4%(-8))/6);
			break;
		default :
			i8 = (5-i16);
		}
	}


	//Method
	public static void meth_8( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
		if( (i11>(i16*i14))){
			i14 = (4-(i2-i3));

		}
		if(((i9+i3)!=(i1-i8))){
			i14 = ((i8+i9)+i13);
		}
		else{
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}
		if( ((i6>=(i11*i19))||(5<=i11))){
			i8 = ((-6)-(-7));

		}if( ((i16+i2)>(i2+i4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((((i3>=(i8/(-6)))||(i10!=i9))&&((-4)!=(i12/8)))&&(i9==(i19+i5)))){
			System.out.println("Hello");
		}
		else{
			meth_7(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}
		if( ((i6*i7)>=9)){
			i8 = (i15*i18);

		}
		if((i2<=(-6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			meth_4(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}

		for(int i = 0; i < 5; i++){
			if( (i1==(-4))){
				i1 = (i2+i9);

			}
		}

		if((i2>(i15%2))){
			System.out.println("Hello");
		}
		else{
			i2 = ((i19-i3)-(i17*i0));
		}

		if((i6>4)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((-6)>i3)){
			i15 = (i8/6);

		}if( (i0==5)){
			i5 = ((i3%(-3))/8);

		}
		if((i9!=i11)){
			i9 = ((-7)/(-3));
		}
		else{
			i4 = (7+(i2+i10));
		}

		for(int i = 0; i < 4; i++){
			if( (((i18*i4)!=i17)||((i1%(-6))>=3))){
				i3 = ((i1-i5)+(i1%5));

			}
		}

		switch(i10){
		case 0:
			i1 = (i15-i4);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 8; i++){
			if( ((i12>1)&&(i5>(-8)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 4; i++){
			if( ((i17*i15)<=6)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if((i8!=i19)){
			i9 = (i2/(-1));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (8<=(i3%5))){
			i7 = ((i16-i8)*(-6));

		}
		if(((i19<=(i7%5))&&(2<=(i8*i2)))){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i18 = ((-9)*(i0*i19));
		}

		for(int i = 0; i < 5; i++){
			i3 = ((-5)-i14);

		}
		if( ((-3)==(i5+i9))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i0){
		case 0:
			i3 = i14;
			break;
		case 1:
			i1 = ((-2)-i2);
			break;
		case 2:
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			break;
		case 4:
			i1 = ((-5)*(i13%7));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i12%3)>9)){
			i2 = (4-6);

		}
		if((((i15==i4)&&((i6/5)>8))||((-8)>(i10-i8)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
		}

		switch(i1){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i15 = i13;
			break;
		case 2:
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i12 = (i3/(-4));
		}

		switch(i8){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i14 = ((i19+i13)+(i17%(-7)));
		}

		for(int i = 0; i < 7; i++){
			if( (i17<8)){
				i3 = ((i2/(-9))/(-4));

			}
		}
		if( ((i9<(-7))||(1<i19))){
			i2 = (i10/1);

		}
		for(int i = 0; i < 3; i++){
			if( (i2>=(-8))){
				i9 = ((i15-i4)+i7);

			}
		}

		for(int i = 0; i < 2; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i6){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			i3 = ((-8)+(i1*i3));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i11 = (5-(i18+i6));
		}

		for(int i = 0; i < 4; i++){
			if( ((-3)<(i10+i9))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if((((i3%2)!=(i14+i3))&&((i7/7)<=(i7-i2)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i9 = (i2%(-5));
		}
		if( (i13<=i10)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i13){
		case 0:
			i14 = (i3*i16);
			break;
		case 1:
			i4 = ((i17-i0)+(i4%(-1)));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i18 = ((-4)+(i5/1));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i11>i6)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
		}

		switch(i7){
		case 0:
			i5 = 9;
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i17 = (i13*(i12%8));
		}
		if( ((i10>(i9-i1))||(7<=i11))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (((i3*i0)>i2)||(5<i9))){
			i9 = (8+4);

		}
		if((i11>=i17)){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (((i1+i10)<i1)||((-9)<=(i14-i17)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((-4)<(i16*i7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i1<=(i17*i19))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i3){
		case 0:
			i19 = ((i16/4)*i6);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i9 = ((-9)%(-7));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i5/(-9))<=(i9%2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i15){
		case 0:
			i10 = ((i8/(-1))/(-4));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i1 = ((i14%1)-(i6*i11));
		}

		for(int i = 0; i < 9; i++){
			if( (((3>=i2)||(i7<(i9/3)))||(((i10%(-5))==i2)||(i10<=i15)))){
				System.out.println("Hello");

			}
		}
		if( ((-8)>i0)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i10/(-7))<i1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 9; i++){
			i15 = i4;

		}
		if( (7>i5)){
			i9 = (i6-i15);

		}if( ((((i10+i3)==(i11+i8))&&(i16!=(i12%(-4))))&&((i4*i3)>i16))){
			i16 = (i18%4);

		}
		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i12 = (i10*i18);
		}
		if( ((-9)<=(i19-i17))){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i7>i9)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 5; i++){
			if( ((-5)==i8)){
				i19 = (5/1);

			}
		}

		for(int i = 0; i < 2; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 4; i++){
			if( (8<(i7/(-5)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((-9)<=i9)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 8; i++){
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 1; i++){
			if( (i15<5)){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 1; i++){
			if( (i7<7)){
				i17 = 1;

			}
		}

		switch(i0){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i0 = (i16*(i18%(-6)));
		}

		if((((i10<=1)&&(4!=(i14*i13)))||(i19>=8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i2==(-4))){
			i17 = ((-5)-i8);

		}
		if((i15!=2)){
			i13 = ((i15+i4)*(i3%7));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i13/(-1))>(i17*(-8)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((7<i7)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i5 = (i18+(-1));
		}
	}


	//Method
	public static void meth_9( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		switch(i1){
		case 0:
			i1 = (i1*(-5));
			break;
		case 1:
			i1 = (i9+i11);
			break;
		case 2:
			i1 = (8*(-8));
			break;
		default :
			i1 = (8+i12);
		}
		if( (i9==8)){
			System.out.println("Hello");

		}if( (i2==i8)){
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

		}
		for(int i = 0; i < 8; i++){
			if( ((i19-i14)<(i10-i9))){
				i8 = (5+i19);

			}
		}

		if((i9!=(i4*i9))){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i9 = (5%(-4));
		}

		for(int i = 0; i < 6; i++){
			if( (((i4*i0)<=i7)||(i14>=(i5/5)))){
				i2 = ((i19/(-4))+i7);

			}
		}
		if( ((-9)<i7)){
			meth_4(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

		}
		switch(i2){
		case 0:
			meth_7(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			meth_4(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 9; i++){
			i9 = (i12%(-6));

		}

		switch(i8){
		case 0:
			i5 = ((i14%2)/5);
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i5 = (-7);
			break;
		default :
			i4 = 4;
		}

		if((i3==(i6-i4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i0 = (i8*i13);
		}
		if( (i3==3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i19<=3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 6; i++){
			i19 = i5;

		}

		if((((i7*i19)!=(i15/(-8)))||((((i10-i11)>=(i16-i1))||(8==i12))&&((i6/6)>(i17+i3))))){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i2-i6)<(i10/(-5)))){
			i10 = (i7-(-7));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i5>(-2))){
			i10 = ((i13*i17)/(-6));

		}
		if((i7>=(-2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((4<(i6/4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i8 = ((-4)%(-6));
		}
		if( ((-3)<=(i12%(-2)))){
			i9 = i17;

		}
		for(int i = 0; i < 8; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 1; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i1){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((-6)!=i19)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i12){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i10>=(-3))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (((i12*i14)!=(i15/3))||(i11==(-4)))){
			System.out.println("Hello");

		}if( (((i15/5)<i7)&&(i4>=i1))){
			i14 = (6/2);

		}
		for(int i = 0; i < 5; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i4 = i13;
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i3<=6)||(i0>=i7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i4*i11)>=(i16*i3))){
			i12 = (i17%1);

		}
		switch(i16){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i5 = ((i4%(-7))/(-9));
			break;
		case 2:
			i10 = (i10/8);
			break;
		case 3:
			i1 = (i10/(-8));
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i2){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i0 = ((i19+i12)*(i9/(-2)));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i12<7)){
			i0 = ((i12-i3)%(-9));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((-4)<i0)){
			i4 = (i17*8);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i6<1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 5; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		if((8<=i1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i5 = (i16+(i13/9));
		}
		if( (((-7)!=i18)||(((-8)>=(i5*i11))||(i13>=2)))){
			i15 = ((i16/5)+7);

		}
		switch(i15){
		case 0:
			i3 = i1;
			break;
		case 1:
			i0 = (i12-6);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i16){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i12 = (i16/5);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i2){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i4 = ((i10+i6)+i6);
			break;
		case 2:
			i19 = 6;
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			if( ((((i19-i15)!=i18)&&(i15<(-6)))&&(9>i17))){
				i2 = (8*i1);

			}
		}
		if( ((-1)==i12)){
			i14 = (1%5);

		}
		switch(i10){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i12 = (i5/5);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i12 = (5/(-6));
		}

		for(int i = 0; i < 4; i++){
			if( (((-8)!=(i4%3))&&((i0%(-3))!=i16))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if((((i19*i13)<=i10)&&(i19!=i3))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((((i19*i16)<i5)||((((-3)!=(i3-i1))&&((i13*(-3))!=(-4)))||((6>=i3)&&((i7+i13)>=i6))))&&((i15%5)!=(-3)))){
			System.out.println("Hello");

		}
		switch(i11){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i12 = (i9%8);
			break;
		case 2:
			i18 = ((i16/(-6))-i9);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i10){
		case 0:
			i19 = (i10-i16);
			break;
		case 1:
			i7 = (i18/(-9));
			break;
		case 2:
			i10 = (7%2);
			break;
		default :
			i12 = i5;
		}

		for(int i = 0; i < 5; i++){
			if( ((i15%2)!=i16)){
				i0 = ((-9)%(-8));

			}
		}

		for(int i = 0; i < 7; i++){
			if( (((i17%(-2))<6)||((i19*i5)<=i18))){
				System.out.println("Hello");

			}
		}
		if( (((i19-i5)!=i18)||((i8-(-2))<=(i15%6)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i13){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i19 = (4-(i17+i12));
		}

		for(int i = 0; i < 3; i++){
			if( (i4!=(i10%6))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((i9+(-5))>(i16-i12))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i2<(i14-i3))){
			i16 = (3+9);

		}
		if((i3<=(i5*i1))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
		}

		if((i1<=i12)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i1 = i11;
		}

		for(int i = 0; i < 4; i++){
			i2 = ((-3)%(-4));

		}

		switch(i16){
		case 0:
			i1 = i12;
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i15 = ((-9)-(i18/5));
		}

		for(int i = 0; i < 8; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
	}


	//Method
	public static void meth_10( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		for(int i = 0; i < 7; i++){
			i1 = ((i0-i6)+1);

		}

		if((i1<8)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i0 = (i3/(-8));
		}

		switch(i16){
		case 0:
			i6 = i5;
			break;
		case 1:
			meth_5(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 2:
			meth_9(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 3:
			i6 = (i2+i19);
			break;
		default :
			meth_6(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}

		if(((((i14<=9)||((i0-i11)>i18))&&(i17<=i19))&&((i12<=(-9))||((i4/(-5))<=6)))){
			i3 = i19;
		}
		else{
			meth_3(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}
		if( (1==(i10+i8))){
			i14 = i10;

		}
		if(((i6+i15)<(i14*i8))){
			i17 = (i12*i17);
		}
		else{
			i1 = (1%(-2));
		}
		if( ((-9)>=i16)){
			i18 = (i10/9);

		}
		if(((i3<=3)||(i16!=i0))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			if( ((i13-i2)>=(-3))){
				System.out.println("Hello");

			}
		}
		if( (i0<=(i14/(-5)))){
			i15 = ((i9%(-9))%(-8));

		}
		for(int i = 0; i < 3; i++){
			if( ((-7)<=(i5*i11))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i6){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i14 = i9;
		}
		if( ((i10-i1)>=i5)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i6<(-6))){
			System.out.println("Hello");

		}
		if((i5<=7)){
			i1 = (i8%9);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i5){
		case 0:
			i4 = (3-i11);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i2<8)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (((i6-i7)==(-4))&&(i12<=(i19*i11)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i8){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i15 = ((i14*i12)%(-7));
			break;
		case 2:
			i17 = ((i2-i4)/3);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i5-i3)==5)){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((3<=(i5/2))||(i3>i13))){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((((i4!=i2)&&(i9>5))||((i3+i2)>=(i0-i3)))&&((i10+i11)!=i13))){
			i4 = ((i9+i6)*(i4-i11));

		}if( (i10<=7)){
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i17*i7)>i15)){
			i19 = ((i10%4)-(i12%5));

		}
		for(int i = 0; i < 7; i++){
			if( (((i11<i8)&&(i1>=i12))&&((4>(i4%6))||(((((i0%(-5))==(-2))&&((i6%(-5))!=i14))&&((-7)==i7))||(i14>=i0))))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if(((i13+i15)>i16)){
			i4 = 8;
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i0){
		case 0:
			i17 = ((i6*i19)-(i4+9));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i9 = (2+i19);
		}

		switch(i2){
		case 0:
			i9 = (i11/(-8));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i3 = (8*i7);
		}
		if( ((-2)>i4)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i7/(-7))!=i1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i6 = ((-9)-i6);
		}
		if( (i9==(-2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i17){
		case 0:
			i12 = (i16/2);
			break;
		case 1:
			i8 = i5;
			break;
		default :
			i5 = ((i19/(-6))+(i3/6));
		}
		if( ((i0+(-4))>(-1))){
			i11 = 8;

		}
		if(((i19%(-1))==(i14%8))){
			i17 = ((i11/6)/(-4));
		}
		else{
			System.out.println("Hello");
		}

		if((i3!=(-9))){
			i14 = (i10%(-2));
		}
		else{
			i7 = (1/6);
		}

		switch(i0){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i16 = ((-3)%(-2));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((-5)<i4)){
			i15 = (2/2);

		}
		for(int i = 0; i < 3; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i7){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i1 = ((i12+i0)+(-5));
		}

		if((7<=i19)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((((-5)==(i15+i7))||(i7<=i2))||((-1)<=i10))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i14){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i15){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i13 = (i16/(-2));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i7<=i1)){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i4+i2)<(i9+i14))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i7){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i14 = (-5);
			break;
		case 2:
			i16 = (i18*(i12-i13));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i18<=(i7*i15))){
			i10 = (i11/(-5));

		}
		if((i5<(i5%(-1)))){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i15){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i15 = ((i10/(-4))+(i13-i16));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i3==5)){
			i12 = (i3+(i16-i3));

		}
		if((i9<=(i14-i1))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 6; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( ((i3*i6)==6)){
			System.out.println("Hello");

		}
		switch(i17){
		case 0:
			i12 = i1;
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i11 = ((i16*i2)+(-3));
			break;
		case 3:
			i17 = ((i11-i4)+(-7));
			break;
		default :
			i2 = ((-1)*i14);
		}
		if( ((i15+i2)!=3)){
			i16 = i11;

		}
		for(int i = 0; i < 2; i++){
			if( (i12>=i4)){
				System.out.println("Hello");

			}
		}

		if(((i19>(-9))&&(i13>(-5)))){
			i9 = (i0%2);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 3; i++){
			i0 = (i18/9);

		}
		if( ((i7-i15)!=(i3*i14))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i8-i17)!=(i17/(-7)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i3 = (i17+2);
		}

		switch(i15){
		case 0:
			i19 = ((i3%(-6))+(i3+i19));
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			i10 = ((i11*i12)/5);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i0 = ((-5)*i2);
		}

		switch(i18){
		case 0:
			i7 = (i4/3);
			break;
		case 1:
			i13 = ((-6)*(i5%7));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i9 = i18;
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i16 = ((-7)*2);
		}

		if((i10==i14)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((5==i4)&&((6>=(i1%1))||((i3*i14)>=i5)))){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i13 = ((i8%(-8))/9);
		}
	}


	//Method
	public static void meth_11( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		for(int i = 0; i < 7; i++){
			i12 = ((i12*i5)/6);

		}
		if( (i14<=i16)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i4*9)==i4)){
			meth_8(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

		}
		for(int i = 0; i < 4; i++){
			if( ((i19*i11)<i17)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i9){
		case 0:
			meth_3(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i9 = (6/7);
			break;
		default :
			i14 = (i17*i8);
		}
		if( ((i6*i3)>(i2/5))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i6/(-6))==i2)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
		}

		switch(i5){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i17 = ((-5)-(i15%(-9)));
		}

		for(int i = 0; i < 7; i++){
			if( (2<=(i13-i4))){
				i9 = (i1/(-7));

			}
		}

		switch(i0){
		case 0:
			i17 = ((i8%2)+i15);
			break;
		case 1:
			i4 = ((i12*i15)/(-4));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i19 = (i5*i10);
		}

		if(((i12/2)>=i15)){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((-6)==(i17%(-4)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i5 = (-1);
		}
		if( (i17>(i8%(-6)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i18){
		case 0:
			i4 = (i6+i1);
			break;
		case 1:
			i8 = (7-(-2));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
		}

		switch(i9){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i12 = 4;
		}

		if(((i2+i13)==i17)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i12>i16)){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 6; i++){
			i10 = (i12-i3);

		}

		switch(i13){
		case 0:
			i17 = ((i8+i4)-i9);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i13 = (i13*2);
		}

		if((i10!=(i5+i14))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (9==i6)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i2!=(i14/(-1)))){
			i10 = (i12/(-2));

		}
		switch(i4){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((-9)>(i19+(-2)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i15<=(i11%9))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i10<=7)&&((((-1)<=i19)&&(((-6)<(i16-i11))&&(i14<=i15)))||((i7+i14)>=i6)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i5<=(i15+i7))){
			i14 = (9-i0);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i12==i1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((8!=(i6/(-9)))){
			i7 = (i16+i13);
		}
		else{
			i4 = ((i1-i17)*(i1+i8));
		}

		if((1<=(i10%1))){
			i15 = (i9/9);
		}
		else{
			i4 = (i0*(i15-i19));
		}

		switch(i1){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i8 = (i12+i11);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i3 = (i4+(-2));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i2){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i7 = (9*i4);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i13 = ((-2)/(-6));
			break;
		default :
			i18 = (-2);
		}

		switch(i13){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i11 = ((i17/(-4))-i4);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i6 = i8;
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((-6)==(i6+i13))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((((-7)==i16)&&((-3)<(i17+i6)))){
			i9 = ((i6-i1)%(-1));
		}
		else{
			i12 = ((-4)*i17);
		}

		for(int i = 0; i < 5; i++){
			if( ((i17%(-1))!=(-7))){
				i3 = ((i4%3)*(i6/(-6)));

			}
		}

		switch(i9){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i18/(-7))<=i15)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i0!=8)){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 8; i++){
			if( ((i3>i4)&&(i13<=i18))){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 7; i++){
			if( (i4>=(i5*i8))){
				i13 = ((i16%9)+6);

			}
		}

		switch(i11){
		case 0:
			i9 = ((-5)-(i3*i10));
			break;
		case 1:
			i15 = (1+(i6-i0));
			break;
		case 2:
			i16 = ((-1)+i13);
			break;
		case 3:
			i10 = (7*i18);
			break;
		default :
			i11 = (i18-(i0-i12));
		}
		if( ((i5<=(i18/(-7)))&&(i12<(i0%1)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i12-i7)==i2)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i13/(-7))!=i16)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i11!=(i13/(-3)))){
			i7 = (i10-i2);

		}
		for(int i = 0; i < 5; i++){
			i5 = ((i1%8)*(i18%2));

		}

		if((i9!=(-2))){
			i6 = (7*(i11%(-3)));
		}
		else{
			i3 = (-8);
		}

		for(int i = 0; i < 3; i++){
			if( (1!=(i19+i4))){
				i9 = (8+(i2/4));

			}
		}

		switch(i9){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			break;
		case 3:
			i10 = i1;
			break;
		case 4:
			i13 = ((-1)%(-5));
			break;
		default :
			i13 = ((-2)+i12);
		}

		for(int i = 0; i < 9; i++){
			if( ((i10>=2)&&((i9*i4)<=(i11+7)))){
				i0 = (1-(i2*i18));

			}
		}
		if( (6>(i14/7))){
			i15 = (i1*i13);

		}
		for(int i = 0; i < 1; i++){
			if( ((-3)>i15)){
				i15 = (i17*(-3));

			}
		}
		if( (i3>=(i11+i7))){
			i8 = i3;

		}
		for(int i = 0; i < 5; i++){
			if( (((i0+i5)!=(i14*i13))&&(3>=i16))){
				i8 = (4+(i10%9));

			}
		}

		for(int i = 0; i < 7; i++){
			if( ((i9-i19)>=i13)){
				i18 = ((-7)-i12);

			}
		}

		for(int i = 0; i < 7; i++){
			if( ((i11%(-5))>i7)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i16){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i6 = i3;
			break;
		case 2:
			i19 = i1;
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i3 = 8;
		}

		switch(i19){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			i18 = ((i6%(-7))%(-9));
			break;
		case 2:
			i7 = i4;
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i15){
		case 0:
			i0 = ((i14*i8)*(i17*i16));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i3 = ((-4)-i16);
			break;
		default :
			i6 = ((i14/(-8))%(-2));
		}

		if(((-8)<i10)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 7; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 1; i++){
			if( (3!=(i0/2))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i1){
		case 0:
			i2 = (3%(-3));
			break;
		case 1:
			i9 = (i6/7);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i3 = (i10/(-3));
		}

		for(int i = 0; i < 1; i++){
			if( (i8<=(i0*i4))){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((i10>(-7))&&(i19>4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}}


	//Method
	public static void meth_12( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		for(int i = 0; i < 4; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 1; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( ((i2*i16)>(-7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((1==(i1-i15))&&(i8<(-6)))){
			i8 = ((i2/(-2))/(-3));

		}if( ((3<(i11+i14))||(i6==(i11+i9)))){
			i11 = (6+(-9));

		}
		switch(i19){
		case 0:
			meth_11(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			i1 = ((i18+i6)*i9);
			break;
		default :
			meth_11(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}

		if(((i2-i9)<i13)){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i16){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i9 = (i0+i4);
			break;
		case 3:
			System.out.println("Hello");
			break;
		default :
			i13 = (6/4);
		}
		if( (i18<=(-1))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i15%9)==(i18+i6))){
			i9 = (i5%(-4));

		}
		for(int i = 0; i < 9; i++){
			if( (i5>=5)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if(((i14/(-8))!=(i7%(-4)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((-7)<=(i6/6))){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 6; i++){
			if( ((-8)>i0)){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 9; i++){
			if( ((i18-i11)<=6)){
				i18 = (1+i11);

			}
		}
		if( (i5==(-1))){
			i1 = ((i8/2)-i8);

		}
		switch(i6){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			break;
		case 3:
			i8 = i12;
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i8 = ((-8)-(-6));
		}

		for(int i = 0; i < 6; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i2){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i9 = ((i14%7)/(-5));
		}

		if((i2>=1)){
			i12 = (i1/(-8));
		}
		else{
			i1 = ((-2)+i7);
		}

		if((i12==6)){
			i10 = (i16+2);
		}
		else{
			i9 = ((i19/(-6))+i1);
		}

		switch(i6){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i11 = (i16%(-1));
			break;
		default :
			i17 = (8%6);
		}

		switch(i13){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i10 = (i4%(-8));
			break;
		case 3:
			i14 = (i0*i15);
			break;
		case 4:
			i14 = i10;
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i8>=1)){
			System.out.println("Hello");

		}
		switch(i7){
		case 0:
			i2 = ((i3-i2)+i7);
			break;
		case 1:
			i18 = i3;
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i4 = (7%9);
			break;
		default :
			i11 = (i1%(-6));
		}

		for(int i = 0; i < 9; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( (((i13%1)<=(i2%(-3)))||((i16>i10)||((i3*i4)<=i12)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((((i3-(-3))==(i2+i17))&&((-9)!=i4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i2 = ((i7/1)-i12);
		}
		if( ((i12+i13)<=(i10-i12))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i12==(i16-i10))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i11 = (i10-(i14%(-6)));
		}

		for(int i = 0; i < 2; i++){
			if( (i13==(i4*i6))){
				i4 = 3;

			}
		}

		switch(i13){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i17 = (-4);
			break;
		default :
			i6 = ((i6-i19)+i2);
		}

		for(int i = 0; i < 5; i++){
			if( (1<=i0)){
				i6 = (3%8);

			}
		}

		switch(i1){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i6-i15)<=i18)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i18>i15)){
			i5 = 4;

		}if( ((i17!=(i9*i11))&&((i15-5)>2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i14+i7)!=(-7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i8){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i19 = (9%(-3));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i4!=4)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((-6)>=i1)){
			i12 = (i18%(-6));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 9; i++){
			if( (3>(i0%(-8)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if(((i6+i19)>1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i2>=3)){
			i17 = ((i1/7)%9);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i10){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 9; i++){
			if( (i19>=i8)){
				System.out.println("Hello");

			}
		}

		if(((((i5%(-1))!=(i0*3))&&(((i8-i1)>=i15)&&((-5)<=i11)))&&(i17<(i16/2)))){
			i7 = ((i5*i16)%(-2));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i3>6)&&(5>i9))){
			i9 = ((-1)/(-7));

		}if( (i5>5)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i18<i6)||(i8!=(i17-i14)))){
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i17>=i11)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 7; i++){
			if( ((i11==(i7/(-9)))&&(5<=i9))){
				i18 = (i2/1);

			}
		}

		for(int i = 0; i < 6; i++){
			if( ((i7+i11)>i4)){
				i11 = (8/1);

			}
		}

		switch(i4){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			i12 = (i16-(i0+i5));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i6 = (6/(-8));
		}

		for(int i = 0; i < 3; i++){
			if( ((i2-i12)<i12)){
				i18 = (i18-(i15+i3));

			}
		}

		switch(i6){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i5 = ((i14-i9)/(-4));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i9 = ((i14-(-3))/(-6));
		}

		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i2 = (6+(i17/(-9)));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}
	}


	//Method
	public static void meth_13( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		if((((-2)<=i2)&&((i11%3)>=(i18*i3)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i2 = i1;
		}

		switch(i18){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			meth_7(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 2:
			meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 3:
			meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 5; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i10){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i10 = (8+(i7*i3));
			break;
		default :
			System.out.println("Hello");
		}
		if( ((i14*i4)>=i14)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 1; i++){
			if( ((-9)>(i17*i9))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 9; i++){
			if( (i2!=i9)){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if(((-8)>(i6%8))){
			i1 = i7;
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((-8)==(i7+i2))){
			i18 = (i1-(i11*i0));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i12<(-3))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i3 = ((i9-i11)/(-5));
		}

		for(int i = 0; i < 1; i++){
			if( ((i4+i17)>i16)){
				i3 = (i0%(-4));

			}
		}
		if( ((i0+6)>=i13)){
			System.out.println("Hello");

		}
		if(((i12*i7)<8)){
			i18 = (-8);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 9; i++){
			if( (((-7)<(i15*i6))||(i5<i3))){
				i9 = (1*(i0-i18));

			}
		}
		if( (i7!=(i8/(-7)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 5; i++){
			if( ((i17<i14)&&(9<(i1/(-7))))){
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 6; i++){
			if( (((i17+i6)<3)&&(i2>=(-6)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			break;
		default :
			i1 = (i1%(-7));
		}
		if( ((i4<=(i15%3))||(i16>=(i9/2)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 5; i++){
			if( ((8==(i17%8))||((((i2<=6)||((-6)<=i13))&&((i9-i7)>=(-9)))&&((i16+i3)<(-2))))){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 4; i++){
			i8 = (i4*9);

		}

		for(int i = 0; i < 3; i++){
			if( (i0<=(i18*i16))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( (i0<(i19-i16))){
			i5 = (i5/6);

		}if( (i14!=(-7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i3==(-5))){
			i6 = (5/(-8));

		}
		for(int i = 0; i < 3; i++){
			if( ((i15+i10)<i4)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if((i5>=(i19%(-8)))){
			i3 = (i14%(-2));
		}
		else{
			i8 = ((-9)+i17);
		}

		if((i10==i2)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 7; i++){
			if( ((i6+i2)<=i17)){
				i5 = ((i14-i8)/8);

			}
		}

		switch(i5){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i16 = 6;
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i1*i5)==1)){
			i19 = (-6);

		}
		if(((-7)<=i8)){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i3 = ((i9-i18)+i5);
		}

		switch(i15){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((((-8)>=i2)||(3>=i9))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i5*i3)<=7)){
			i8 = 9;

		}if( (i18<=1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i8){
		case 0:
			i2 = (i11*i10);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i19>i5)){
			i1 = 5;

		}
		if((i18==(-1))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i0 = i15;
		}

		if((i11!=7)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i8 = (i6+i17);
		}

		switch(i1){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i19 = (i13-(-1));
		}
		if( (i17<=3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 4; i++){
			if( (i10!=i1)){
				i14 = (i10*i14);

			}
		}

		switch(i14){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i15*i12)==(i4%8))){
			i5 = (i11*i14);

		}if( (((i16>=(-9))&&((i16/5)>=(-6)))||(i14==i2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 7; i++){
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 2; i++){
			if( (7>=i2)){
				i7 = (9*(i12-i16));

			}
		}

		if(((i12!=i4)&&((i11%(-2))!=3))){
			i13 = ((-9)/8);
		}
		else{
			i18 = (3-(-3));
		}
		if( ((i6-i17)!=i2)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i18==(-4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i6){
		case 0:
			i0 = (1/5);
			break;
		case 1:
			i4 = 6;
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i0+i11)>(-5))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i8<(i14*i11))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i13>=9)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i13 = (i7-i16);
		}
		if( ((i3>=i4)&&(i8<(i9/1)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i3){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i9 = 7;
			break;
		default :
			i9 = ((i2%8)-(-6));
		}

		switch(i18){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i5==(-4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i15 = (6*(i14/9));
		}

		switch(i13){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i10 = (7+5);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i9){
		case 0:
			i9 = (i3-(-4));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i0 = (i11+7);
		}
	}


	//Method
	public static void meth_14( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		if((i8<=i1)){
			i1 = ((i17*i3)*(-4));
		}
		else{
			i3 = (i2-(-3));
		}

		switch(i5){
		case 0:
			i1 = (9-i6);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i1 = (i18*(i5-i7));
		}
		if( ((-5)!=i6)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i11*i18)!=(-9))){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i14){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i8 = (-3);
			break;
		case 2:
			meth_13(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 3:
			meth_8(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		default :
			i11 = ((-6)-i14);
		}

		for(int i = 0; i < 5; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 6; i++){
			if( ((-5)>=i8)){
				meth_13(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

			}
		}

		for(int i = 0; i < 8; i++){
			if( ((i5+(-1))>=(i12*i9))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if(((i8/4)>(-7))){
			meth_4(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}
		else{
			i2 = ((i8-i12)*i10);
		}

		if(((i14-i9)>=(i0%9))){
			i6 = ((i3-i15)-(-9));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i0/4)>=(i7-i14))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i6){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i8 = (1%(-6));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i6 = ((i12%(-1))+(-5));
		}
		if( (((i0%1)>=(-9))||((i7+i16)==(i12+(-5))))){
			i17 = i12;

		}
		if(((-9)>=(i2-i7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i10==(i15-i5))){
			i18 = i19;
		}
		else{
			System.out.println("Hello");
		}
		if( (2>=(i15*i11))){
			i17 = (4+(-4));

		}
		for(int i = 0; i < 9; i++){
			if( ((-4)>(i9*i5))){
				i19 = ((i4+i3)-(i1%7));

			}
		}

		switch(i17){
		case 0:
			i0 = (7*i9);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i10 = i8;
		}

		switch(i10){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i15 = ((-9)%(-4));
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i4 = (5%1);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i5 = ((-3)%(-3));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i4){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i1 = ((-8)/9);
			break;
		default :
			i7 = i11;
		}

		if((i8<i3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 8; i++){
			i6 = ((-6)+i15);

		}

		if(((-4)>=(i1%(-9)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
		}

		if(((i3>=7)&&(i2!=(i4/(-4))))){
			i6 = (i7-(i16+i3));
		}
		else{
			i0 = (i1*(i2/(-3)));
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (9<=i12)){
			i17 = (i11+i6);

		}
		for(int i = 0; i < 3; i++){
			if( (i0==(-5))){
				System.out.println("Hello");

			}
		}

		switch(i4){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i14>i1)){
			i2 = (i7+(i9*i13));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 9; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 1; i++){
			if( (i13<=(-2))){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( (((1<=(i2%6))&&((i15!=4)&&((i9%8)!=i5)))||((((2<(i12-i14))||((i0-i15)<i2))&&(((-6)!=i2)&&(6>=i5)))&&(i15>=(i14/(-1)))))){
			i8 = i6;

		}
		for(int i = 0; i < 9; i++){
			if( (1>i6)){
				i6 = (4/(-6));

			}
		}

		for(int i = 0; i < 2; i++){
			if( (((-2)>(i7+i15))||((i10+7)!=6))){
				System.out.println("Hello");

			}
		}
		if( ((-8)!=(i19-i16))){
			System.out.println("Hello");

		}
		for(int i = 0; i < 4; i++){
			if( (((i0+i4)!=(i4*i17))||((9>=i11)&&((i8+i7)!=i0)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if((i4!=2)){
			i19 = (i10/(-1));
		}
		else{
			i4 = ((-2)-(i4*i7));
		}
		if( (i19==5)){
			i14 = ((i9*i4)%2);

		}
		if((((i3+i14)!=(-2))||(i0!=(-7)))){
			i17 = (2*(i2-i14));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 6; i++){
			if( ((-4)<(i11/(-6)))){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i13){
		case 0:
			i0 = (5%(-4));
			break;
		case 1:
			i10 = i17;
			break;
		case 2:
			i3 = (i8%5);
			break;
		case 3:
			i5 = (9%(-5));
			break;
		default :
			i15 = (i14+(-6));
		}

		switch(i16){
		case 0:
			i5 = ((-5)*i4);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i4>4)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i10/1)>=(i6*i19))){
			i14 = (7-i9);
		}
		else{
			i16 = 6;
		}
		if( ((-5)>(i10+i11))){
			i0 = i3;

		}
		switch(i11){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			i7 = i0;
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 5; i++){
			if( ((i1+i10)==i1)){
				i19 = (i14%(-2));

			}
		}

		if(((6==(i0*5))&&((i3+i14)==(i14%5)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i0 = ((i7%(-7))/9);
		}

		for(int i = 0; i < 6; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		if(((i14/(-9))>=i5)){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i5 = (i14+(i4*i2));
		}
		if( ((i13<=3)||(i5<(-4)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i12!=8)){
			i16 = ((i16*i2)%1);
		}
		else{
			i9 = ((i11+i19)-i18);
		}

		switch(i16){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i16 = (i12+i0);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		if(((-9)<i7)){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i2*i8)<=1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i2>=(-5))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i8/(-4))<9)){
			i12 = (i5/6);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i16){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i10 = ((-2)/5);
		}

		switch(i5){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i7 = (i7%7);
			break;
		case 3:
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
	}


	//Method
	public static void meth_15( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		switch(i1){
		case 0:
			meth_5(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			i1 = 6;
			break;
		case 2:
			i1 = (i15*(i3/3));
			break;
		case 3:
			i3 = (6%1);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((9<=(i14/(-5)))){
			i14 = (i19%5);
		}
		else{
			i1 = (4*i8);
		}
		if( (i8==(-2))){
			System.out.println("Hello");

		}if( ((i1+i4)>=i15)){
			meth_6(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

		}if( ((4>=(i17*i0))||((i11/(-2))<=i15))){
			meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

		}if( ((-2)==i17)){
			i1 = (i11%4);

		}if( ((i4+i12)==(-5))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (7<i6)){
			meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

		}
		for(int i = 0; i < 8; i++){
			if( ((i12<=(-1))&&(i18>(-7)))){
				i15 = ((i13*i10)/3);

			}
		}

		if(((i8<=(i4*i3))&&((i8/(-2))>=(-5)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i10 = (i11%1);
		}

		for(int i = 0; i < 2; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		if(((i1*i15)!=2)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((2>(i4+i1))||(i7>(i15+i19)))){
			i8 = ((-9)-(i6*i8));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((-1)>=(i6*i13))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( (((i7/(-5))==i14)||(((i4/9)==(-3))&&(i13>6)))){
			i17 = (4+(i0-i10));

		}
		switch(i6){
		case 0:
			i8 = (i13+i17);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i15 = (i3-(i12+i4));
			break;
		case 4:
			i14 = ((-9)/1);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((-8)<i7)){
			i2 = i11;
		}
		else{
			i1 = (i19*i15);
		}

		if((i17!=(i1-i17))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i19+i12)!=i5)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 3; i++){
			if( (8==i0)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( (i11<=5)){
			i1 = (i15*1);

		}if( ((3>i2)||(9<=(i0+i2)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i18){
		case 0:
			i3 = ((i5-i6)*(i5+i12));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i15){
		case 0:
			i9 = (4*(i12%3));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i1!=7)&&(i6<2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i13!=(-2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 5; i++){
			if( ((i18-i3)>=(-2))){
				i8 = (i2+5);

			}
		}

		for(int i = 0; i < 8; i++){
			if( ((i13==(i6-9))&&(i4>=(i14-i17)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 5; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 3; i++){
			if( ((-7)<=i15)){
				i0 = i5;

			}
		}
		if( ((i0+i16)<i5)){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i0){
		case 0:
			i2 = ((i19*i11)-i7);
			break;
		case 1:
			i15 = ((i16+i15)*(i2+i3));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i11 = (6/2);
		}
		if( (((i2*i19)<3)&&((i3*i12)==i16))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i16){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i14 = (3%(-5));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((8==(i19-i0))){
			i10 = (i10-(i0+i16));
		}
		else{
			i17 = ((i6+i10)-2);
		}

		switch(i5){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i18 = ((-4)-(-4));
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i8){
		case 0:
			i7 = i1;
			break;
		case 1:
			i19 = ((i5-i4)+(-2));
			break;
		default :
			i15 = (7-i3);
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i6 = (i19+5);
			break;
		default :
			i6 = i9;
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i11 = (i0%(-2));
			break;
		case 2:
			i13 = ((-5)/(-3));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i19/1)>(i16+i8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
		}
		if( (i15==(i7*i8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i8){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((((i2-i17)>=8)||(i7<i15))&&(((i3%3)>=i1)&&(((i7+i15)<(-6))||(((-4)<=(i1-i18))&&((i19<=i5)&&((i2/3)>(i14%9)))))))){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i14>=i18)){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
		}

		for(int i = 0; i < 6; i++){
			if( (i18<3)){
				i15 = (-6);

			}
		}

		if((i1>=(-7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i4!=i19)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 5; i++){
			if( (((i0/2)>=(i14+9))&&((i7%(-8))<=(i2/8)))){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((-9)!=i3)){
			i6 = ((i2+i14)/9);

		}if( (((i10*i1)<i12)||((i16+i14)!=i1))){
			System.out.println("Hello");

		}
		for(int i = 0; i < 8; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		if(((i12>=(i3*i5))||(i4>(-3)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 8; i++){
			i14 = (4/(-8));

		}
		if( ((i11*i4)<8)){
			i18 = ((-4)*i17);

		}
		for(int i = 0; i < 7; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		if(((i8/(-6))>(i3*i15))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i6 = ((i7+i0)%5);
		}

		switch(i19){
		case 0:
			i2 = ((-3)%(-5));
			break;
		case 1:
			i18 = (9-i10);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i16 = (i1/1);
		}

		switch(i7){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i4 = (i17%9);
			break;
		case 2:
			i15 = (i18+i2);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i1!=(i13/2))){
			i15 = ((i8*i18)/(-1));

		}if( (i7>=7)){
			i10 = ((-1)%5);

		}
		for(int i = 0; i < 6; i++){
			i15 = (i15%(-4));

		}
		if( ((i8==(-7))&&(i16!=(i4/(-1))))){
			i2 = (i5/7);

		}if( ((i9/(-9))==3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i2/(-3))>=6)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i7 = ((-5)*(-1));
		}
	}


	//Method
	public static void meth_16( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
		if( (i5>(-5))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i3==(-2))){
			meth_11(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}
		else{
			meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}

		for(int i = 0; i < 8; i++){
			if( (i15!=1)){
				meth_5(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

			}
		}

		switch(i12){
		case 0:
			meth_8(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i12 = (i7%7);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i15 = ((-9)%8);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((9<=(i14/5))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 8; i++){
			if( ((4==i1)&&((i4-i7)==(i14+i15)))){
				i7 = 2;

			}
		}

		if((i12<(-4))){
			i14 = ((i18-i15)+(-4));
		}
		else{
			System.out.println("Hello");
		}

		switch(i1){
		case 0:
			i14 = ((-4)*9);
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			i7 = (5-i10);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i7 = i2;
		}
		if( ((i10*i16)<=i8)){
			i18 = ((i2*i10)*9);

		}
		if(((i0+i6)<=i14)){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 4; i++){
			if( (i8==6)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i3){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			i7 = (6*7);
			break;
		default :
			System.out.println("Hello");
		}
		if( (i3==8)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i15<=i16)){
			i2 = ((-6)-(i19/1));

		}
		if(((i10-i18)!=i8)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((-1)!=i7)){
			i15 = (i13%(-9));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 4; i++){
			if( ((-3)>=i13)){
				i14 = ((i14*i4)-(-1));

			}
		}

		switch(i10){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			i5 = (i13+(i5-i6));
			break;
		case 2:
			i6 = (-4);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 7; i++){
			if( ((-5)>=i10)){
				i6 = ((i3*i17)*i6);

			}
		}
		if( (((4>(i11/(-7)))||(i18>=(-7)))||(i3<(i9-i4)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 3; i++){
			if( (5<(i4-i5))){
				i4 = (i8+i7);

			}
		}
		if( (i2<=(i7*i9))){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i1){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			i5 = ((i10+i1)*i14);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i16){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i2 = (i5/(-4));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i16 = (i4*(i14*i18));
		}

		for(int i = 0; i < 4; i++){
			if( (2!=(i5+i19))){
				i8 = (2*i1);

			}
		}

		if((4<i3)){
			i18 = (i15/(-7));
		}
		else{
			i6 = (i7*(i18%2));
		}

		if(((i4+i10)>i13)){
			i4 = ((i16-i12)/(-6));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i8<=(i16-i17))){
			i13 = ((i5%7)%(-6));

		}
		if((9<(i13/(-8)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i19 = (i9-6);
		}

		if((i4>=7)){
			i8 = (1+(i2/(-3)));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i17){
		case 0:
			i1 = (i3%8);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i10 = ((i7/5)*(i6+i3));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i11 = ((i5*i13)+3);
		}

		switch(i15){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i14 = 4;
		}
		if( (i10>=1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 5; i++){
			i5 = (i11-i15);

		}

		switch(i17){
		case 0:
			i6 = ((i1%4)+i12);
			break;
		case 1:
			i6 = ((i19*i11)+i5);
			break;
		default :
			System.out.println("Hello");
		}

		if(((i3%5)<=(-2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i3>3)){
			i6 = (1/(-9));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i16!=(-3))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 1; i++){
			if( ((i5%(-6))==i9)){
				i4 = (i13*i14);

			}
		}

		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((-9)!=i18)){
			i17 = (i13-i18);

		}
		switch(i4){
		case 0:
			i13 = (4-(i19%(-4)));
			break;
		case 1:
			i19 = (5/(-7));
			break;
		case 2:
			i6 = ((i10-i12)/(-4));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i17 = (-1);
			break;
		default :
			i3 = ((-2)%2);
		}

		for(int i = 0; i < 6; i++){
			if( (i2>=(i11-i6))){
				i0 = (i0-(i2%2));

			}
		}

		switch(i9){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i8+i6)==i6)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (i0!=9)){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i0-i3)<=i1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((9==(i18-i9))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 8; i++){
			if( (((i19==9)&&(i0>i6))||(((i5!=9)||((i7-i8)>=i11))&&((i13/(-6))>(i16+i19))))){
				i17 = (6+1);

			}
		}

		if((i7>3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i4>i8)){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 8; i++){
			if( ((i7*i13)!=(i2+i15))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((i12%6)>i19)){
			i17 = (i4%(-3));

		}
		if((i7>=(-6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 6; i++){
			i10 = (i6*i18);

		}
		if( (i1<=i11)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 9; i++){
			if( ((i14<=(-1))||(((i18-i10)<=(-8))||(i4==8)))){
				System.out.println("Hello");

			}
		}

		switch(i12){
		case 0:
			i14 = (i14+(-1));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i18 = (i14-i15);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i14==5)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i10 = ((i2/(-1))%(-1));
		}
		if( ((i15*i13)<=(-4))){
			i18 = ((i7%(-4))/7);

		}
		switch(i2){
		case 0:
			i14 = ((-7)*(i17%2));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i16 = (i8*5);
		}
	}


	//Method
	public static void meth_17( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
		if( ((i8+i15)>i3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 3; i++){
			if( ((i7*i8)<=(i4+i9))){
				i8 = ((-1)+i10);

			}
		}

		switch(i5){
		case 0:
			meth_13(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i4 = ((i18*i11)-i17);
		}

		switch(i11){
		case 0:
			meth_12(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i3 = (6/8);
			break;
		default :
			i4 = (6+(i19*2));
		}
		if( ((i17%6)==i11)){
			meth_10(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

		}
		for(int i = 0; i < 3; i++){
			i4 = (2%7);

		}

		if((i0==i4)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i7 = ((-4)/2);
		}

		if((1<i13)){
			System.out.println("Hello");
		}
		else{
			i4 = (i14*(i16/(-3)));
		}

		for(int i = 0; i < 5; i++){
			if( ((i9-i11)<(-2))){
				meth_9(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);

			}
		}
		if( ((i12%(-4))>(i3*(-9)))){
			i3 = (i8*(i18/(-2)));

		}
		for(int i = 0; i < 8; i++){
			if( (1<=i14)){
				System.out.println("Hello");

			}
		}

		if((i13==(i9%(-6)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i11 = ((-7)*(i8%9));
		}
		if( ((-5)==(i1*i3))){
			i15 = i2;

		}
		switch(i6){
		case 0:
			i8 = (i19%5);
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			i16 = ((i18/(-4))*(i12*i9));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i2){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i10 = (i1+i5);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i3-i10)>=(i13-i12))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i19 = (i11-(-1));
		}

		for(int i = 0; i < 4; i++){
			if( ((i4<8)&&((i19-i0)==(i16+i15)))){
				i18 = (i11-(i13+i10));

			}
		}

		if(((i2*i5)>=(i12+i19))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i12*i15)<i2)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 7; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( ((i8-i17)!=(-8))){
			i6 = ((-5)-i6);

		}
		if(((i11+i12)<i7)){
			i14 = ((i0+i11)-(i3-i12));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			i15 = (i7/1);
			break;
		case 3:
			i12 = ((i5+i13)/5);
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i1 = ((-4)*(i13%4));
		}

		if((i10>=i5)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 3; i++){
			System.out.println("Hello");
			System.out.println("Hello");

		}

		if((((-7)!=i13)&&((i5/7)>(i1/(-3))))){
			i6 = (i15/(-2));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i18>=(-5))){
			System.out.println("Hello");

		}
		switch(i5){
		case 0:
			i0 = ((i2*i16)*(i15%6));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i13 = ((i13/(-1))+(i11+i14));
		}

		if((((i11!=i7)&&((-1)>(i8/(-8))))&&((i9/(-6))<(i19-i4)))){
			i4 = (1*1);
		}
		else{
			i18 = ((i1+i8)%9);
		}

		if((((i16+1)>=(i15-i3))&&((-9)>=i7))){
			i1 = (-7);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i15/(-5))>i0)){
			i10 = (-5);

		}
		switch(i4){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i10 = (i14/4);
			break;
		default :
			i1 = (i4+i18);
		}

		for(int i = 0; i < 4; i++){
			if( (i1<6)){
				i8 = i5;

			}
		}

		for(int i = 0; i < 8; i++){
			if( (((i14%(-6))<=6)&&((i19+i17)>(i2*i1)))){
				i19 = ((i16+i0)/(-6));

			}
		}

		if(((i7/(-7))!=i19)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i8 = ((-5)/9);
		}
		if( (((i12==(i11+i7))||(((-8)==i15)||(i1>=(-4))))||((i9+i4)<(-6)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i6){
		case 0:
			i9 = ((i5/9)/(-6));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i16*i3)==i13)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i7){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i12){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			i5 = ((i1%1)/(-3));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i12 = i17;
			break;
		default :
			i1 = ((i10*i6)-6);
		}

		for(int i = 0; i < 4; i++){
			if( (((i1*i17)<i3)&&(i17<i19))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i6){
		case 0:
			i16 = (i16-i13);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i6 = (i19%2);
		}
		if( ((i14*i10)==i3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i7%8)>=(i13-i10))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((-1)<=i2)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i13>3)&&(i15>=(-2)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((((((i7+i10)<9)&&(i1==i14))||((i6/(-4))<=(i0*i16)))||(i14>=i16))){
			i16 = (i2+4);
		}
		else{
			System.out.println("Hello");
		}

		for(int i = 0; i < 5; i++){
			if( (8<i1)){
				i13 = ((i6-(-9))-i16);

			}
		}

		if((((8==i11)&&((i3+i11)>=i2))||((((-4)==i4)||(i15<=(i6+i3)))||((i6+i15)<(i6+i1))))){
			i5 = ((i17+i8)+i9);
		}
		else{
			System.out.println("Hello");
		}

		if((1>(i0-i16))){
			i2 = ((i3+i1)%4);
		}
		else{
			i9 = i18;
		}

		if((((i14/1)!=(i15+i2))||(6==i15))){
			i4 = ((-6)*(i8/8));
		}
		else{
			i13 = ((i1%6)%(-3));
		}

		if(((i9/6)>=(i6/(-8)))){
			i11 = i1;
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i1-i12)<=(-6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i7<=(-4))||((-5)<(i2%(-8))))){
			i18 = ((-9)+i19);

		}
		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i17 = i8;
			break;
		default :
			i3 = (i19/8);
		}

		for(int i = 0; i < 4; i++){
			i5 = (9*(i17-i5));

		}
		if( (((i13-i1)<2)&&((-6)==i16))){
			i13 = ((i15-i13)%7);

		}
		for(int i = 0; i < 4; i++){
			if( (i6!=(-2))){
				i5 = (3+i1);

			}
		}

		if(((((i17*i18)!=(-3))||((i6%(-8))<5))&&((-9)==(i4-i0)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i19 = ((i3*i16)+(-2));
		}
		if( (i8>i15)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i5){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i14==i4)){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((((i2+i11)<=(i19-i9))&&(i0<(-8)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 6; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( (i5>(-6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((-9)>i19)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i2/(-1))==(-8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((i17>=i7)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((-1)<=i6)){
			i1 = (i18%2);

		}
		if((i11<=(-2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i7+i5)<i4)){
			System.out.println("Hello");

		}
		for(int i = 0; i < 1; i++){
			if( ((i10/(-6))>2)){
				i1 = (i12%1);

			}
		}
		if( ((i8/(-6))!=(-7))){
			i19 = ((i16+i6)/3);

		}if( (((((i13-i18)<5)||((i19%(-3))!=6))&&(((i13-i15)>i19)&&((-7)<(i6/(-5)))))||(3>=(i16%(-4))))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i11){
		case 0:
			i15 = (7%(-3));
			break;
		case 1:
			i10 = (-9);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
		}
	}


	//Method
	public static void meth_18( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		for(int i = 0; i < 6; i++){
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i0){
		case 0:
			meth_15(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			i0 = (-6);
			break;
		case 2:
			meth_5(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		default :
			i0 = ((i3/(-8))-1);
		}

		switch(i7){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i8){
		case 0:
			meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			i0 = ((i14+i12)%5);
			break;
		case 2:
			i8 = (3*(i1-i6));
			break;
		case 3:
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i14 = ((-1)%(-3));
		}

		if((i15>=i18)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i6 = ((-7)-i2);
		}

		for(int i = 0; i < 6; i++){
			if( (i5!=2)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 4; i++){
			if( (4==(i16+i8))){
				i3 = (i2-(i14%3));

			}
		}

		switch(i12){
		case 0:
			i8 = (i13+i3);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i0 = (i0*(-3));
			break;
		case 3:
			i8 = (i0+(-6));
			break;
		default :
			i14 = ((i10%(-5))+8);
		}

		if(((-8)<=(i10/(-2)))){
			i7 = (i17%(-7));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 6; i++){
			if( ((i7*i11)<i19)){
				i14 = (i18+i16);

			}
		}

		if(((i3-i18)<=i1)){
			i6 = (i19-(i0/3));
		}
		else{
			i1 = (i12-(i2+i11));
		}

		switch(i5){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i10){
		case 0:
			i11 = ((i0+i7)%8);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i13 = (i10+(i0-i2));
		}
		if( ((-7)<=(i4+i3))){
			i2 = (i5+(i2/(-6)));

		}if( (((i4*i2)==(i0+i18))&&(((((i4<(i11*i4))||((((i1/(-3))>=i1)||((i19/(-8))<=(i17/1)))&&(3!=i14)))&&(((-7)<i16)&&(i16<(-4))))||((i18+i13)<=i1))||(i1==(-7))))){
			i14 = ((i2%(-7))+(-4));

		}if( ((i1/9)<=7)){
			System.out.println("Hello");

		}if( ((i7%(-8))<=(i15-i12))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((((i10-i1)==(i11-(-3)))&&((i0*i4)>(-4)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i8 = (i4*i3);
		}

		for(int i = 0; i < 8; i++){
			if( (((i1*i2)>(-9))&&(i7==(-6)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((i8%1)==(-4))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( ((i3>(-5))&&(i0>=i12))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((((i2+i10)>=i1)&&(i5!=7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
		}

		switch(i14){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i9%(-1))>=(i18%(-8)))){
			System.out.println("Hello");

		}
		switch(i11){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i16 = ((i13*i19)%(-3));
			break;
		case 2:
			i1 = ((i15-i1)*(i17/(-4)));
			break;
		default :
			i10 = 7;
		}
		if( (i12<i11)){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 9; i++){
			System.out.println("Hello");

		}

		if(((i2!=(i14+i6))||(i5<=2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((7<i13)||((i1-i2)>i12))){
			i15 = ((-9)+(-8));

		}
		for(int i = 0; i < 1; i++){
			if( (((i8-i16)<=i3)||(i0<=(-4)))){
				i2 = (-1);

			}
		}
		if( (((i7!=i17)&&(i8>(i6%(-8))))||(i17<(-3)))){
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (((((-5)<(i18+i5))||((i13-i17)<=(-3)))||((-4)!=i7))&&((3<=i8)&&(i8!=(-2))))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}if( (((i4<(-8))||((i6!=(i11%(-3)))&&(((i18/(-1))<(-1))&&(1==i10))))||((i13+5)<(i7+i2)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i12){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i15 = ((i4%7)-(i1%(-7)));
			break;
		default :
			i11 = i1;
		}
		if( ((i0*i16)<(i15*i13))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i0){
		case 0:
			i16 = (i14*i3);
			break;
		case 1:
			i10 = i5;
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i1 = i9;
			break;
		default :
			i11 = (i11/7);
		}

		for(int i = 0; i < 2; i++){
			if( (i8<i14)){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if((i19==i11)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i9 = ((i4*i16)+6);
		}
		if( ((i5/3)==1)){
			i18 = (8-i17);

		}
		for(int i = 0; i < 2; i++){
			if( (9<=i17)){
				System.out.println("Hello");

			}
		}

		if((i18<3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i6){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i14 = ((i4/5)/4);
			break;
		case 2:
			i12 = ((i13-i11)*i1);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i12+i7)>=i10)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i2 = ((i18+i15)%2);
		}

		for(int i = 0; i < 5; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i15){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i10 = (9+2);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((1<=(i4%8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i17 = ((-6)%(-8));
		}

		for(int i = 0; i < 3; i++){
			if( ((i5*i7)!=9)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if((i12==(-2))){
			i10 = ((i11/(-6))*(i0%7));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i4%6)!=i5)){
			i3 = i19;
		}
		else{
			i19 = (9+(-4));
		}

		for(int i = 0; i < 4; i++){
			if( (i4==(-5))){
				i18 = ((-4)/8);

			}
		}

		switch(i13){
		case 0:
			i10 = (i16*i9);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i8 = 2;
			break;
		default :
			i3 = (i14%(-6));
		}
		if( ((i12-i2)<=(i10+i13))){
			i9 = ((-4)/9);

		}
		for(int i = 0; i < 2; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( (i2>=(-2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 9; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 9; i++){
			if( (((i18-i15)!=i3)&&((3<=(i15*i0))||((i13*i12)>=9)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( (i3!=7)){
			i7 = ((-7)/(-9));

		}
		for(int i = 0; i < 4; i++){
			if( (i18!=6)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i11){
		case 0:
			i9 = ((i8%5)/(-1));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i17){
		case 0:
			i17 = ((-8)*(i0%(-3)));
			break;
		case 1:
			System.out.println("Hello");
			break;
		case 2:
			i17 = (i5*4);
			break;
		default :
			i8 = (-3);
		}

		for(int i = 0; i < 2; i++){
			if( (i1>=(i18-i15))){
				i3 = i19;

			}
		}
		if( ((-9)<=i12)){
			i3 = (i18+i19);

		}
		for(int i = 0; i < 2; i++){
			if( (((-4)>(i9*i6))&&(i1<=i14))){
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i9){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i7 = ((i13*i17)/(-9));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 3; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 7; i++){
			i19 = ((-6)*(i16-i9));

		}
		if( (((i3%5)==i19)||(9>(i6/8)))){
			System.out.println("Hello");

		}
		switch(i13){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
	}


	//Method
	public static void meth_19( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		switch(i5){
		case 0:
			i5 = ((i1/(-8))-i5);
			break;
		case 1:
			meth_7(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 2:
			i1 = (i17+(i2/(-8)));
			break;
		default :
			meth_15(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}

		for(int i = 0; i < 3; i++){
			i5 = i19;

		}

		if((i4==(-3))){
			meth_13(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		}
		else{
			i19 = (i2-(-9));
		}

		for(int i = 0; i < 3; i++){
			i12 = ((i18%5)%1);

		}

		switch(i7){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			meth_13(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i7<=(-2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i11){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i1 = (i11/7);
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i18 = (5-i14);
			break;
		default :
			i5 = (i2%3);
		}

		if(((-8)<=i12)){
			i3 = ((i8*i9)%3);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 6; i++){
			if( ((i5+i1)>=i10)){
				i17 = (i1*i10);

			}
		}

		for(int i = 0; i < 3; i++){
			if( (i13==6)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 1; i++){
			i13 = (6*(-7));

		}

		switch(i11){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i4<3)){
			i17 = ((i7-i1)-i8);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i2<(i13-i8))){
			i9 = (i5-(i4+i10));

		}
		for(int i = 0; i < 8; i++){
			if( (((i18+i1)==i14)||((i19!=3)&&(i15>6)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 5; i++){
			System.out.println("Hello");

		}

		switch(i16){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 7; i++){
			if( ((i5*i2)==(i17+i2))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 4; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		for(int i = 0; i < 8; i++){
			i7 = (i7-i2);

		}

		if(((-6)==i6)){
			i13 = (i19-(-7));
		}
		else{
			i6 = i10;
		}

		if((1==(i9-i15))){
			System.out.println("Hello");
		}
		else{
			i18 = ((-2)-i7);
		}

		if((i17>3)){
			i7 = (1-(i5*i11));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i8){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i12 = ((i8-i13)/6);
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i16){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i2 = ((i18-i2)+(i11%8));
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( ((i17-i1)>=i17)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if((2<i15)){
			i6 = ((i11/9)+i6);
		}
		else{
			i19 = ((i4/(-8))%(-4));
		}

		switch(i17){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
		}

		for(int i = 0; i < 1; i++){
			if( ((i8%1)<i2)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( ((i16/(-3))==(i19*i2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 3; i++){
			i9 = (i10%(-6));

		}
		if( ((-3)!=(i1*i8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i8){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i4 = (i12-1);
			break;
		case 2:
			i10 = ((i6/(-4))-2);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i14<(-2))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i19){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i2 = (8*(i4*i16));
			break;
		case 4:
			i4 = (i11%(-7));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			i11 = (i2*i7);

		}

		if((((3!=(i14%8))&&(5!=(i19-i8)))&&(2==i11))){
			i9 = ((-1)-(-8));
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i14<=(-3))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 6; i++){
			i6 = (i6/(-3));

		}
		if( ((i8+i19)==(i6-i7))){
			i10 = (i1%(-5));

		}
		switch(i2){
		case 0:
			i17 = ((-8)+(-8));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i0 = ((i11+i5)+(i4+i0));
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i5*i14)!=(-5))){
			System.out.println("Hello");

		}
		for(int i = 0; i < 7; i++){
			if( ((i11%9)!=i15)){
				System.out.println("Hello");

			}
		}

		if(((i4*i7)==1)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i1){
		case 0:
			i15 = i4;
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i6){
		case 0:
			i6 = (i13/(-7));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i18 = (i6-i19);
			break;
		case 3:
			i0 = (3/9);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i1>5)&&((i6%7)==i8))){
			i8 = (-9);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i9/7)!=(-4))){
			i18 = ((i6%2)/(-5));

		}if( (i1<i0)){
			System.out.println("Hello");

		}
		for(int i = 0; i < 8; i++){
			if( (4>(i8%6))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 8; i++){
			if( (i11<=i0)){
				i17 = ((i14/(-6))+(i5*i15));

			}
		}

		for(int i = 0; i < 7; i++){
			if( ((i10-i11)==1)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if(((i10!=(-4))&&(8>=(i0/7)))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i14 = ((i2-i10)+i16);
		}

		if((i1>=(-6))){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i17==4)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i14==i11)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i7 = ((i11%(-7))*i6);
		}

		switch(i10){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i14 = (i9%(-8));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
		}
	}


	//Method
	public static void meth_20( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

		if((i2==(-7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i2 = (5%1);
		}
		if( (i7>=(i8+i10))){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i16){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			meth_18(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 2:
			i10 = (1+(i6+i14));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i14){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			meth_4(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		default :
			i7 = (3/7);
		}

		switch(i3){
		case 0:
			meth_16(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i16 = (i4/(-1));
		}

		switch(i9){
		case 0:
			meth_12(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i14 = (i4*(i6+i14));
			break;
		default :
			i3 = (i18%(-1));
		}
		if( ((-5)<(i4/7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i11){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i4 = ((i17/3)+4);
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i2 = (i12+i17);
			break;
		default :
			i2 = ((i0*i11)%(-8));
		}

		if((i16>(i1%6))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i3 = (i1-i15);
		}

		for(int i = 0; i < 2; i++){
			i17 = (2%(-6));

		}

		for(int i = 0; i < 2; i++){
			if( (4>=i5)){
				i14 = ((i8-i12)-(i3/1));

			}
		}

		if(((i10*i5)>=(i4*i9))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i5 = (-5);
		}

		for(int i = 0; i < 4; i++){
			i12 = (i1%(-8));

		}

		switch(i5){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i6 = ((i6/2)/2);
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i14){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i8 = (i19+(i18/(-9)));
			break;
		default :
			i2 = 8;
		}

		for(int i = 0; i < 1; i++){
			if( (i17>=(i18%9))){
				System.out.println("Hello");

			}
		}

		switch(i1){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			i7 = (i18+(i9+i13));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 2; i++){
			if( ((i10+i9)>2)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		switch(i13){
		case 0:
			i5 = (i19%(-2));
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((i19-i0)==(i17+i15))){
			i7 = ((i16-i12)/2);

		}
		switch(i2){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i9 = ((i13*i12)-(i8+i6));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 9; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( ((4!=i8)&&(4==i16))){
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if(((i9-i7)<(-8))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( ((-9)>=(i1%(-3)))){
			i19 = ((i11*i2)*(-5));

		}
		switch(i8){
		case 0:
			i19 = ((i8+(-2))/9);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 4:
			i19 = ((-2)+(-8));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if((i15<=(i10%7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i19 = ((i5+i16)/(-8));
		}

		if(((-7)==(i5*i7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i19%(-8))<(i11-i12))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		for(int i = 0; i < 4; i++){
			if( ((i6%6)==(i4+i6))){
				i15 = i6;

			}
		}

		if(((i1/6)<=(i2%(-7)))){
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i1+i19)<4)){
			i16 = ((i14*i10)-9);
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		if( (i11>=4)){
			i5 = (1/8);

		}
		for(int i = 0; i < 8; i++){
			if( ((i8+i10)>(i9+i18))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 8; i++){
			if( (((i18!=i8)&&((i9*i6)<=1))&&((i6*i16)<=(-8)))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if(((i14/2)!=i14)){
			i18 = (3/(-5));
		}
		else{
			i19 = (i13/(-9));
		}

		for(int i = 0; i < 1; i++){
			if( ((i19/6)>(i17+i2))){
				i10 = (3-i15);

			}
		}

		for(int i = 0; i < 8; i++){
			if( ((-2)!=i7)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if(((i7+i2)>i11)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		switch(i2){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 3:
			i19 = ((-9)*(-9));
			break;
		default :
			i19 = (i14-(i13/6));
		}

		for(int i = 0; i < 9; i++){
			if( ((i10/5)>=i14)){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		if(((((i17*i2)>(i3-i10))&&(i6>i18))&&(i10<i0))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i4 = ((i18*i5)*i6);
		}

		for(int i = 0; i < 5; i++){
			if( (i10<=(-3))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}
		if( (i3>3)){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i9){
		case 0:
			i12 = (-7);
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 2:
			i17 = (9*(i4-i19));
			break;
		default :
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
		}

		if(((i14-i13)!=5)){
			System.out.println("Hello");
			System.out.println("Hello");
		}
		else{
			i15 = (5/(-7));
		}
		if( ((i6==(-4))&&(i9<1))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		for(int i = 0; i < 3; i++){
			if( (2==(i19-i15))){
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");
				System.out.println("Hello");

			}
		}

		for(int i = 0; i < 1; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}

		switch(i8){
		case 0:
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i18 = ((i1/4)+(-3));
		}

		for(int i = 0; i < 7; i++){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		if( ((i10<(i5%(-8)))||(((i17!=(-6))||((i5/(-9))<(-6)))&&((i7+i0)!=i14)))){
			i17 = ((i4-i17)+(i6*i3));

		}if( ((1>=(i0*i7))||((i2+i13)==7))){
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");

		}
		switch(i3){
		case 0:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		case 1:
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			System.out.println("Hello");
			break;
		default :
			i3 = ((i14/(-4))%(-3));
		}
	}
	public static void entryMeth(int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
		meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_3(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_4(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_5(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_6(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_7(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_8(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_9(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_10(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_11(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_12(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_13(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_14(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_15(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_16(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_17(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_18(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_19(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
		meth_20(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
	}

	public static void main(String[] args) {
		entryMeth(Integer.parseInt(args[0]),
				Integer.parseInt(args[1]),
				Integer.parseInt(args[2]),
				Integer.parseInt(args[3]),
				Integer.parseInt(args[4]),
				Integer.parseInt(args[5]),
				Integer.parseInt(args[6]),
				Integer.parseInt(args[7]),
				Integer.parseInt(args[8]),
				Integer.parseInt(args[9]),
				Integer.parseInt(args[10]),
				Integer.parseInt(args[11]),
				Integer.parseInt(args[12]),
				Integer.parseInt(args[13]),
				Integer.parseInt(args[14]),
				Integer.parseInt(args[15]),
				Integer.parseInt(args[16]),
				Integer.parseInt(args[17]),
				Integer.parseInt(args[18]),
				Integer.parseInt(args[19]));
	}

}