package com.accenture.lab.carfast.test;


public class Test2K {
private static int i0;
private static int i1;
private static int i2;
private static int i3;
private static int i4;
private static int i5;
private static int i6;
private static int i7;
private static int i8;
private static int i9;
private static int i10;
private static int i11;
private static int i12;
private static int i13;
private static int i14;
private static int i15;
private static int i16;
private static int i17;
private static int i18;
private static int i19;
public Test2K(){
}


//Method
 public static void meth_1( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

if(((-8)>(i17+i0))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
}

switch(i8){
case 0:
i8 = ((i1+i19)*(-7));
 break;
case 1:
i19 = ((-9)+i3);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i8+i17)<=i3)){
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 6; i++){
 System.out.println("Hello");

}

for(int i = 0; i < 9; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if( (i14<=(i19+i17))){
i14 = (i4/(-1));
if( (i13!=(i8/1))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i18<1)){
System.out.println("Hello");
System.out.println("Hello");

}
}
}
if((i10>(i19*i12))){
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( ((i5+i13)<=(i9%6))){
i1 = (i19*(i11-i15));
if( ((-6)>=(i19/(-4)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i12>=(i18+i6))){
System.out.println("Hello");
System.out.println("Hello");
if( ((i12/(-7))!=(i13/(-5)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}
}
switch(i6){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
}

switch(i14){
case 0:
i18 = ((-7)%2);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i10 = ((i5/(-9))-(-5));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 2; i++){
 if( (((i19/(-1))<i19)&&(i17<=3))){
i17 = (-5);
if( ((i7*i8)!=i5)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i19<(i7+i1))){
i18 = (2/5);
if( ((-5)!=i14)){
i7 = i10;
if( (1<i0)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}
}
}
}

switch(i10){
case 0:
i10 = (-5);
 break;
case 1:
i14 = (i0+2);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i6 = (-1);
}
if( (((i14+i13)!=i10)||(i18<5))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i0){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i1 = ((i1-i19)*(i6-i17));
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i12==(-2))){
i5 = ((i7*i8)/(-5));
if( ((i7-i2)==i7)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (((i8*i5)>=(i13/1))&&(i13>(i15*i11)))){
i15 = (5+i18);
if( (3>=(i16-i17))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (i12<(-6))){
i13 = (8*i0);
if( (i18>6)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}
}
}
}
for(int i = 0; i < 9; i++){
 if( (i11>6)){
System.out.println("Hello");

}
}

switch(i11){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i3 = ((-8)-(i2-i11));
}
if( ((i6/(-6))!=i8)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( (8>i6)){
i8 = ((i11+i13)-(-4));

}
}
for(int i = 0; i < 1; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if( (((-2)==i3)&&(i14>=(i8*i16)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( (i6<=4)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 6; i++){
 if( ((-6)>i0)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

switch(i9){
case 0:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i19){
case 0:
System.out.println("Hello");
 break;
case 1:
i16 = (i1+i9);
 break;
case 2:
i18 = (i7%(-2));
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
 break;
default :
i18 = (5/6);
}

for(int i = 0; i < 4; i++){
 if( (i8==i19)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 8; i++){
 if( ((-7)>i14)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( ((i15-i2)!=i2)){
i2 = i19;
if( (((-8)<=(i15%5))&&(i3<i5))){
i8 = (i19*2);
if( ((i19+i6)<(i13/9))){
i1 = (3+i18);
if( ((i8+i18)<(-2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
if( ((i14/(-5))>=i18)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}
}
}
}
}

for(int i = 0; i < 6; i++){
 if( ((i4-i3)<i12)){
System.out.println("Hello");

}
}
if( (((i6==i18)||(((i14*i8)<=(-8))||((-5)>(i7%8))))&&(i1>=(-4)))){
i12 = (i10+(i0+i7));

}
for(int i = 0; i < 4; i++){
 if( (i7>(i17/(-1)))){
i1 = (4*1);

}
}
if( (i6!=2)){
i14 = i5;

}if( ((i8%8)>i12)){
i1 = (i2%1);

}if( ((i1==i0)||(i9<i7))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i13%4)==i17)){
i0 = 2;

}
if((i16!=(-4))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
}

switch(i1){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 8; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 6; i++){
 if( ((i3+i4)<=(-6))){
i7 = ((-8)/(-6));

}
}
if( (i2<=2)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i6+i13)>(-6))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( (8>(i9+i10))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( (i17<=i8)){
i16 = ((i9*i11)*i8);

}if( (i12<(i16-i0))){
i1 = ((-8)+9);

}
for(int i = 0; i < 1; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 9; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 9; i++){
 i10 = (i0-i12);

}

switch(i11){
case 0:
i10 = (1%1);
 break;
case 1:
System.out.println("Hello");
 break;
default :
i1 = ((i2*i14)*(-6));
}
if( ((1>i15)&&(i14>=5))){
System.out.println("Hello");
System.out.println("Hello");

}
switch(i0){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i12 = (i2+(i16-i12));
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
}


//Method
 public static void meth_2( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

if(((i17<(-6))||(i10!=1))){
i17 = (i13%9);
}
else{
 i17 = (i5/9);
}
if( ((-6)>i3)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if(((-6)<i1)){
i10 = (i16*8);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 4; i++){
 if( (i18!=5)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
if( (((i17+i8)>=(-2))&&(i19>(i1-i0)))){
System.out.println("Hello");

}if( (i16!=(-7))){
i1 = (i13*i18);

}
switch(i5){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i1 = ((i7%2)+i8);
 break;
case 2:
i2 = (9+(-8));
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i5){
case 0:
i16 = ((i7/(-6))-i17);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( ((i15!=(-2))||(i16==6))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i16>=(-1))||((i2+i0)>=8))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i10/(-5))<(i1%2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i0){
case 0:
i5 = ((-4)%4);
 break;
case 1:
i0 = (i11+i19);
 break;
case 2:
i13 = i8;
 break;
case 3:
i3 = (i2+(-3));
 break;
default :
i0 = (4%9);
}

switch(i19){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i1 = (2+i13);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 8; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

switch(i9){
case 0:
i15 = ((i7*i14)/2);
 break;
case 1:
i5 = (i18+7);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i14 = (i16+(i11/(-9)));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i19+i8)!=(-1))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
}
if( (i19<(i17-i5))){
i16 = (i2/3);

}
for(int i = 0; i < 7; i++){
 if( ((i14*i6)!=7)){
i14 = ((i12+i11)-(i15+i5));

}
}

for(int i = 0; i < 8; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 6; i++){
 if( ((i11*i0)<(i11%4))){
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 8; i++){
 if( (4!=i13)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 4; i++){
 if( ((i8/(-5))!=(i5+i18))){
System.out.println("Hello");
System.out.println("Hello");

}
}

if(((i10*i8)>(i3/(-3)))){
i17 = 9;
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i13){
case 0:
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i10 = ((-7)%6);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i0){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
}

switch(i10){
case 0:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i17 = (i1+1);
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i10==i7)&&((i18<i15)||(i18<=i12)))){
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i18 = (i8+(i0%(-8)));
}

if(((-6)>=(i3/(-4)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i2 = i14;
}
if( (((-5)>=(i8*i6))&&(i17>(i1/(-8))))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if((((i17==i8)&&(9!=i19))||(i15>(-8)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i15 = (i10/(-3));
}
if( (i14!=i2)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i0){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i19 = (i12%2);
}
if( (i1==(i4/(-6)))){
System.out.println("Hello");

}if( ((i9/(-2))<7)){
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 1; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

switch(i17){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i4 = (8-(-2));
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
}

if((i9<=(-2))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i6 = ((i4/(-4))/9);
}

switch(i8){
case 0:
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i7 = i14;
}
if( ((-1)>=(i1*i4))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 7; i++){
 if( (i17>(i12%(-7)))){
i10 = (i8-i19);

}
}

if(((i2>3)||((i19/(-9))>=i12))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 1; i++){
 System.out.println("Hello");

}
if( (i6==(-3))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( (((i13+i5)!=(i5/(-9)))&&((i18%(-8))>=(i17-i1)))){
System.out.println("Hello");
System.out.println("Hello");

}
switch(i11){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i7 = (i4/6);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i18 = (2+(-3));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i1==(i1-i5))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((6!=i7)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 9; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 5; i++){
 if( ((i8>=i2)||((-9)==i14))){
i17 = ((-9)-(i1-i4));

}
}

if(((i8-i18)!=(i16*i9))){
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i2 = (1+(-6));
}
if( (((-5)>i1)||(i7==i1))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i6){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
}

switch(i8){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i6 = (i11+i12);
 break;
case 2:
i0 = (i1/(-3));
 break;
case 3:
i3 = ((i7/(-8))-(-1));
 break;
default :
i15 = ((-5)*(i6%4));
}

if((i8!=i9)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
}

for(int i = 0; i < 1; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if( ((i19<=9)&&((-5)<i14))){
i6 = ((i18+i7)%(-4));

}if( ((i17+i9)==i15)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i12<(i19-i12))&&((i1+i17)==(-9)))){
i19 = (i7-i1);

}
for(int i = 0; i < 2; i++){
 i9 = ((i4-i6)/4);

}

if(((i19*i12)!=(i7%6))){
i13 = (i16%(-9));
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i14>(i19*i1))){
i13 = (6%3);
}
else{
 i11 = (i10/2);
}

if(((i11+i18)>=(i13+i5))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
}
if( (8!=i6)){
i14 = ((-3)*7);

}
for(int i = 0; i < 6; i++){
 if( (i8<(i1*i5))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
}


//Method
 public static void meth_3( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){

switch(i15){
case 0:
i15 = (-6);
 break;
case 1:
System.out.println("Hello");
 break;
case 2:
i15 = (i3*(i2+i19));
 break;
case 3:
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 9; i++){
 if( (i17==1)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

if(((i15*i11)==i2)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( ((i11/7)==(i0-i9))){
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 1; i++){
 if( (i4<(i6%2))){
i2 = ((-7)%(-2));

}
}

switch(i16){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i6 = ((-2)%(-5));
}

switch(i5){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
}

switch(i3){
case 0:
i11 = (i10%(-7));
 break;
case 1:
i4 = (i2*9);
 break;
case 2:
i3 = ((-3)-(-4));
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i3 = (-6);
}

switch(i3){
case 0:
i2 = ((i19/(-4))*2);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i2 = ((i16+i12)/(-4));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i16){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i0 = (i7/(-2));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i2){
case 0:
i0 = ((i10+i17)-(i6+i8));
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i15 = (i19%7);
 break;
default :
System.out.println("Hello");
}

for(int i = 0; i < 1; i++){
 System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 1; i++){
 if( ((i9/(-9))!=(i7+i17))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 2; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

switch(i3){
case 0:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( ((i16<i18)&&(8<=(i14%2)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i13%2)>=(i5+i10))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if(((i15/(-1))>i2)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (((i13/(-2))>(i9-(-3)))||(8<(i18%1)))){
i16 = ((i4-i11)/9);

}
for(int i = 0; i < 3; i++){
 if( (i4>(i10-i5))){
i9 = ((i3%(-5))-i9);

}
}

for(int i = 0; i < 9; i++){
 if( ((i0-i10)>(i17+i3))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
if( (i14==(i6%7))){
i17 = ((i10-i19)%(-8));

}
if(((i0!=(-2))&&((-8)>(i18/(-9))))){
i7 = (i0-(i4-i15));
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((((i12%9)==(i6*i17))&&(9>(i16%3)))&&((i1>=(-4))&&((i19-i10)!=6)))){
i1 = (i19-6);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i11){
case 0:
i13 = ((i7-i0)-i13);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i1 = 9;
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i15*i8)>(i11/(-5)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
}

switch(i12){
case 0:
i1 = ((i3%(-5))-1);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i11){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i4 = ((-9)%(-2));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( ((i2*i1)>(-9))){
i12 = (i14/2);

}
switch(i1){
case 0:
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i15 = (2+(i4%9));
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 8; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if( (8<(i16%(-7)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( ((i1*i16)!=(-6))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
if((((-1)!=i7)||((i14+i3)<9))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 i11 = (3-(-1));
}

for(int i = 0; i < 7; i++){
 if( (i1==i0)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
if( ((i14%(-7))==i19)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 4; i++){
 if( (i10!=i5)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

if((i18!=i1)){
i5 = ((-5)%7);
}
else{
 i13 = (6+i3);
}

switch(i14){
case 0:
i9 = (i14/3);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i3){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i12 = (8-4);
 break;
case 3:
i12 = (i14%7);
 break;
case 4:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
i12 = ((i5+i2)/(-1));
}

switch(i5){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 1; i++){
 if( ((-3)>=(i16%(-9)))){
System.out.println("Hello");
System.out.println("Hello");

}
}

if((((i12-i5)==(i2*i18))||((i14+i15)>4))){
i12 = (4%(-2));
}
else{
 System.out.println("Hello");
}

switch(i7){
case 0:
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( ((i19-i2)!=i3)){
i9 = ((i3-i19)%3);

}
for(int i = 0; i < 2; i++){
 if( ((i0*i10)!=7)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 8; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 1; i++){
 if( ((i3%(-4))>=(i6*i17))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

for(int i = 0; i < 2; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 1; i++){
 if( (i4<6)){
i6 = (i11+i1);

}
}
if( (5!=i3)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}}


//Method
 public static void meth_4( int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
if( ((i14-i8)<=(-5))){
i8 = (i7*(-8));

}
switch(i5){
case 0:
i8 = i16;
 break;
case 1:
i5 = ((i15-i1)+(i15%3));
 break;
default :
meth_3(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
}

if(((-2)!=i5)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 1; i++){
 if( ((i6>i10)&&(((i13-i10)>=(i17/(-2)))||(9>i15)))){
System.out.println("Hello");

}
}

switch(i1){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i8 = (i15*i15);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i18!=(-6))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}if( (i18==i17)){
i7 = (8%(-4));

}
switch(i14){
case 0:
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((((6<=i18)&&((i19-i4)<=i3))||((i11-i19)>(-4)))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
}

switch(i12){
case 0:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i14){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i12 = ((i9+i0)*i13);
 break;
case 4:
i13 = ((-2)-(-6));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i14>=(i17+i7))){
i16 = ((i19%7)/4);
}
else{
 i2 = ((i19*i11)-(-3));
}

for(int i = 0; i < 7; i++){
 if( (i0>=7)){
System.out.println("Hello");
System.out.println("Hello");

}
}

switch(i18){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i16 = (i15-5);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i0 = ((i1+i4)+(i15+i17));
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
if( (i9!=i5)){
System.out.println("Hello");
System.out.println("Hello");

}if( ((i15<i9)||((i19/4)>=i11))){
i14 = ((-5)%(-5));

}
for(int i = 0; i < 7; i++){
 if( ((i14/9)>=(i7%8))){
i9 = (1/8);

}
}

if((i16!=i11)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i6){
case 0:
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i8){
case 0:
i4 = (i0+i8);
 break;
case 1:
i7 = ((i8*i11)+i0);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i1 = (8/(-3));
 break;
case 4:
i12 = (3%(-4));
 break;
default :
i14 = (i12-i5);
}

switch(i19){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 5; i++){
 if( (8>i7)){
i9 = (-5);

}
}

if(((-2)!=i3)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((i14/2)<(-9))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if(((-2)==(i9%1))){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 6; i++){
 if( (i13<(-7))){
i12 = ((-7)/(-7));

}
}
if( (i0==1)){
System.out.println("Hello");
System.out.println("Hello");

}
switch(i4){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
i11 = ((i17+i3)/6);
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i8){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
i17 = (5%5);
 break;
case 4:
i19 = (i0-i10);
 break;
default :
i15 = (9/5);
}

if((i10>(-6))){
i18 = (i17+i15);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 8; i++){
 System.out.println("Hello");
System.out.println("Hello");

}

if(((8<=(i18%(-7)))&&((i17+4)<i15))){
i12 = ((i14-i4)%8);
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 9; i++){
 if( ((-7)>i11)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}

switch(i1){
case 0:
i14 = (i18+i14);
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i18 = (i1*i4);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i19){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 3:
System.out.println("Hello");
 break;
case 4:
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i6){
case 0:
i17 = (i1-(i2+i3));
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i16 = (i1+(-6));
 break;
default :
System.out.println("Hello");
}

for(int i = 0; i < 6; i++){
 i11 = (i10+i14);

}
if( ((-6)!=i12)){
i16 = ((i6-i14)+(-9));

}if( ((i13-i8)!=i16)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
switch(i3){
case 0:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i4 = ((i8%2)+(i12/(-2)));
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
}
if( (i7==i13)){
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
for(int i = 0; i < 5; i++){
 if( ((i12%(-1))<=(-2))){
i9 = (8/7);

}
}

for(int i = 0; i < 2; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

switch(i0){
case 0:
i18 = (4%(-8));
 break;
case 1:
i15 = ((i11*i19)%(-7));
 break;
case 2:
System.out.println("Hello");
 break;
case 3:
i6 = (i3+i4);
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

if((i4>(i10%(-8)))){
System.out.println("Hello");
}
else{
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

switch(i14){
case 0:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 1:
System.out.println("Hello");
System.out.println("Hello");
 break;
case 2:
i2 = ((-1)-i0);
 break;
case 3:
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
 break;
default :
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
}

for(int i = 0; i < 6; i++){
 System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 1; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}

for(int i = 0; i < 6; i++){
 System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");
System.out.println("Hello");

}
}
public static void entryMeth(int i0, int i1, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18, int i19){
meth_1(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
meth_2(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
meth_3(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
meth_4(i0,i1,i2,i3,i4,i5,i6,i7,i8,i9,i10,i11,i12,i13,i14,i15,i16,i17,i18,i19);
}

}